package com.aidar;

import java.io.*;

public class TestPyton {
    public static void main(String[] args) throws Exception {
        Process proc;
        String inputFolder = "/Users/dongmeidqi/Documents/projects/chenming/input";
        String outputFolder = "/Users/dongmeidqi/Documents/projects/chenming/output";
        String context = "'{\"drop_row\":5, \"start_threshold_number\":0, \"end_threshold_number\":30}'";
        try {
            String[] cmd = new String[]{"python", "/Users/dongmeidqi/Documents/projects/ds-cidr/processor/creditreview/script/gussican.py", "-id", inputFolder, "-od", outputFolder, "-c", context};
            System.out.println(cmd);
            System.out.println(cmd);
            proc = Runtime.getRuntime().exec(cmd);
            BufferedReader in = new BufferedReader(new InputStreamReader(proc.getInputStream()));
            String line = null;
            while ((line = in.readLine()) != null) {
                System.out.println(line);
            }
            in.close();
            proc.waitFor();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
