package com.aidar.stream;

public class Bar {
    String name;

    Bar(String name) {
        this.name = name;
    }
}
