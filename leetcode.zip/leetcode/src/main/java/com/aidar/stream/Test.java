package com.aidar.stream;

import java.util.*;
import java.util.function.Predicate;


/**
 *
 * https://winterbe.com/posts/2014/03/16/java-8-tutorial/
 *
 */
public class Test {
    public static void main(String[] args) {
        List<String> names = Arrays.asList("peter", "anna", "mike", "xenia");
        Collections.sort(names, new Comparator<String>() {
            @Override
            public int compare(String a, String b) {
                return b.compareTo(a);
            }
        });

        Collections.sort(names, (String a, String b) -> {
            return b.compareTo(a);
        });

        Collections.sort(names, (String a, String b) -> b.compareTo(a));
        Collections.sort(names, (a, b) -> b.compareTo(a));

        /**
         * @FunctionalInterface
         * public interface Converter<F, T> {
         *     T convert(F from);
         *     boolean equals(Object obj);
         * }
         */
        Converter<String, Integer> converter = from -> Integer.valueOf(from);
        Integer c1 = converter.convert("123");
        System.out.println(c1);


        Converter<String, Integer> converter1 = Integer::valueOf;
        Integer c2 = converter1.convert("123");
        System.out.println(c2);

        PersonFactory<Person> personFactory = Person::new;
        personFactory.create("Peter", "Parker");


        int num = 1;
//        Converter<String, Integer> stringConverter = from -> Integer.valueOf(from);
        // local variables, num must be implicitly final for the code to compile. The following code does not compile:
//        Converter<Integer, String> stringConverter = (from) -> {
//            num = 2;
//            return String.valueOf(from + num);
//        };
//        num = 3;


        Predicate<Boolean> nonNull = Objects::nonNull;

    }
}
