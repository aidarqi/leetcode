package com.aidar.stream;


@FunctionalInterface
public interface Converter<F, T> {
    T convert(F from);
    boolean equals(Object obj);
}
