package com.aidar.proxy.dynamic;

public interface Hello {
    void sayHello();
}
