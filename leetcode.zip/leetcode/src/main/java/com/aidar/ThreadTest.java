package com.aidar;

import java.util.concurrent.ThreadPoolExecutor;

public class ThreadTest {
    public static void main(String[] args) {
//        ThreadPoolExecutor
        int COUNT_BITS = Integer.SIZE - 3;
        int CAPACITY = (1 << COUNT_BITS) - 1;
        System.out.println(Integer.toBinaryString(COUNT_BITS));
        System.out.println(Integer.toBinaryString(CAPACITY));
        System.out.println(Integer.toBinaryString(~CAPACITY));
        System.out.println(Integer.toBinaryString(-1));
        System.out.println(Integer.toBinaryString(-1 << COUNT_BITS));
        System.out.println(Integer.toBinaryString(0 << COUNT_BITS));
        System.out.println(Integer.toBinaryString(1));
        System.out.println(Integer.toBinaryString(1 << COUNT_BITS));
        System.out.println(Integer.toBinaryString(2 << COUNT_BITS));
        System.out.println(Integer.toBinaryString(3 << COUNT_BITS));
    }
}
