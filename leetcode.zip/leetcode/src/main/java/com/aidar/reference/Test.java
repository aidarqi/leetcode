package com.aidar.reference;

public class Test {
    public static void main(String[] args) {
        Thread thread = new Thread();
        ThreadLocal threadLocal = new ThreadLocal();
        threadLocal.set("a");
    }
}
