package com.aidar.huawei;

import java.util.*;

public class Main {
    public static void main(String[] args) {
        int res =  0;
        Scanner in = new Scanner(System.in);
        int m = Integer.valueOf(in.nextLine());
        int n = Integer.valueOf(in.nextLine());
        int[][] arrs = new int[n][2];
        for(int i = 0; i < n; i++) {
            int[] arr = new int[2];
            String[] arrStr = in.nextLine().split(" ");
            arr[0] = Integer.valueOf(arrStr[0]);
            arr[1] = Integer.valueOf(arrStr[1]);
            arrs[i] = arr;
        }
        Arrays.sort(arrs, new Comparator<int[]>() {
            @Override
            public int compare(int[] o1, int[] o2) {
                if(o1[0] != o2[0]) {
                    return o1[0] -o2[0];
                } else {
                    return o1[1] - o2[1];
                }
            }
        });
        Queue<TimeNumMapping> minHeap = new PriorityQueue<TimeNumMapping>(new Comparator<TimeNumMapping>() {
            @Override
            public int compare(TimeNumMapping o1, TimeNumMapping o2) {
                return o1.time - o2.time;
            }
        });
        for(int i = 0; i < n; i++) {
            int[] arr = arrs[i];
            if(!minHeap.isEmpty()) {
                TimeNumMapping item = minHeap.peek();
                if(item.time <= arr[0]) {
                    int count = item.num + 1;
                    if(count == m) {
                        res += 1;
                        minHeap.poll();
                    } else {
                        item.time = arr[1];
                        item.num = count;
                    }
                } else {
                    minHeap.add(new TimeNumMapping(arr[1], 1));
                }
            } else {
                minHeap.add(new TimeNumMapping(arr[1], 1));
            }
        }
        System.out.println(res + minHeap.size());
    }

    static class TimeNumMapping {
        int time;
        int num;
        TimeNumMapping(int time, int num) {
            this.time = time;
            this.num =  num;
        }
    }
//    public static void main(String[] args) {
//        int res =  0;
//        Scanner in = new Scanner(System.in);
//        String[] arrStr1 = in.nextLine().split(" ");
//        int N = Integer.valueOf(arrStr1[0]);
//        int E = Integer.valueOf(arrStr1[1]);
//        int preX = 0;
//        int preY = 0;
//        int pointY = 0;
//        for (int i = 0; i < N; i++) {
//            String[] arrStr = in.nextLine().split(" ");
//            int x = Integer.valueOf(arrStr[0]);
//            int y = Integer.valueOf(arrStr[1]);
//            if(preX == 0 && preY == 0) {
//                preX = x;
//                preY = y;
//                pointY = y;
//            } else {
//                res += (x - preX) * Math.abs(pointY);
//                pointY += y;
//                preX = x;
//            }
//        }
//        res += (E - preX) * Math.abs(pointY);
//        System.out.println(res);
////        String[] arrStr1 = list.get(0).split(" ");
////        int N = Integer.valueOf(arrStr1[0]);
////        int E = Integer.valueOf(arrStr1[1]);
//    }
//    public static void main(String[] args) {
//        Scanner scanner = new Scanner(System.in);
//        int M = Integer.valueOf(scanner.nextLine());
//        String str = scanner.nextLine();
//        int N = Integer.valueOf(scanner.nextLine());
//        String[] arrStr = str.split(" ");
//        int j = 0;
//        List<String> list = new ArrayList<>();
//        for(int i = 0; i < M; i++) {
//            if(!list.contains(arrStr[i])) {
//                list.add(arrStr[i]);
//            }
//        }
//        int len = list.size();
//        int[] arr = new int[len];
//        while(j < len)  {
//            arr[j] = Integer.valueOf(list.get(j));
//            j++;
//        }
//        Arrays.sort(arr);
//        if(j < 2*N) {
//            System.out.println(-1);
//        } else {
//            int sum = 0;
//            for(int i = 0; i < N; i++) {
//                sum += arr[i];
//            }
//            for(int i = j - N; i < j; i++) {
//                sum += arr[i];
//            }
//            System.out.println(sum);
//        }
//    }
//    public static void main(String[] args) {
//        Scanner in = new Scanner(System.in);
//        while (in.hasNextInt()) {// 注意，如果输入是多个测试用例，请通过while循环处理多个测试用例
//            int a = in.nextInt();
//            int b = in.nextInt();
//            System.out.println(a + b);
//        }
//    }
//    public static void main(String[] args) {
//        Scanner scanner = new Scanner(System.in);
//        int num = scanner.nextInt();
//        int a = 2;
////        List<Integer> list = new ArrayList<>();
//        while (num != 1 && a <= num) {
//            while (num%a == 0) {
//                num = num/a;
//                System.out.print(a + " ");
//            }
//            a++;
//        }
////        System.out.println(list.stream().map(String::valueOf).collect(Collectors.joining(" ")));
//    }
//    public static void main(String[] args) {
//        Scanner scanner = new Scanner(System.in);
//        while(scanner.hasNext()) {
//            String item = scanner.nextLine();
//            System.out.println(Integer.parseInt(item.substring(2), 16));
//        }
//    }

//    public static void main(String[] args) {
////        Scanner scanner = new Scanner(System.in);
////        while(scanner.hasNext()) {
////            String str = scanner.nextLine();
////            int len = str.length();
////            int remainder = len%8, start = 0, end = 0;
////            for(int i = 0; i < len/8; i++) {
////                start = i*8;
////                System.out.println(str.substring(start, start + 8));
////            }
////            if(len % 8 != 0) {
////                StringBuilder sb = new StringBuilder(str.substring(len - len%8, len));
////                for(int i = len%8; i < 8; i++) {
////                    sb.append("0");
////                }
////                System.out.println(sb.toString());
////            }
////        }
//        Scanner sc = new Scanner(System.in);
//        while (sc.hasNext()){
//            String next = sc.next();
//            while (next.length()>8){
//                String substring = next.substring(0, 8);
//                System.out.println(substring);
//                next = next.substring(8);
//            }
//            int tmp = 8 - next.length();
//            for (int i = 0; i < tmp; i++) {
//                next += "0";
//            }
//            System.out.println(next);
//        }
//    }
//    public static void main(String[] args){
////        List<List<Integer>> inList = new ArrayList<>();
////        Scanner sc = new Scanner(System.in);
////        int count = Integer.valueOf(sc.nextLine());
////        while (count > 0){
////            List<Integer> item = new ArrayList<>();
////            while (sc.hasNext() && count > 0) {
////                item.add(Integer.valueOf(sc.nextLine()));
////                count--;
////            }
////            Collections.sort(item);
////            inList.add(item);
////            count = Integer.valueOf(sc.nextLine());
////        }
////
////        List<Integer> flatted = inList.stream().reduce(new ArrayList<>(), (a, b) -> {
////            a.addAll(b);
////            return a;
////        });
////        flatted.forEach(System.out::println);
//        Scanner scanner = new Scanner(System.in);
//
//        while (scanner.hasNext()) {
//            int n = scanner.nextInt();
//            int[] intArr = new int[n];
//            for (int i = 0; i < n; i++) {
//                intArr[i] = scanner.nextInt();
//            }
//            Arrays.sort(intArr);
//            for (int i = 0; i < intArr.length; i++) {
//                // 第一个数字或者不等于前一个数字都可以输出
//                if (i == 0 || intArr[i] != intArr[i - 1]) {
//                    System.out.println(intArr[i]);
//                }
//            }
//        }
//    }

//    public static void main(String[] args){
//        Scanner sc = new Scanner(System.in);
//        String str = sc.nextLine();
//        String[] s = str.split(" "); //正则表达式实用性更强( str.split("\\s+"))
//        int length = s[s.length - 1].length();
//        System.out.println(length);
//    }

//    public static void main(String[] args){
//        Scanner sc = new Scanner(System.in);
//        String str1 = sc.nextLine().toLowerCase(Locale.ENGLISH);
//        char c = sc.nextLine().toLowerCase(Locale.ENGLISH).charAt(0);
//        int count = 0;
//        for(int i = 0; i < str1.length(); i++) {
//            if(str1.charAt(i) == c) {
//                count++;
//            }
//        }
//        System.out.println(count);;
//    }
}
