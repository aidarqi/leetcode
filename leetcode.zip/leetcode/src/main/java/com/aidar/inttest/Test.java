package com.aidar.inttest;

import java.util.Deque;
import java.util.LinkedList;
import java.util.Queue;

public class Test {
    /**
     * 1006. 笨阶乘
     * @param N
     * @return
     */
    public int clumsy(int N) {
        Queue<Character> queue = new LinkedList<>();
        queue.add('*');
        queue.add('/');
        queue.add('+');
        queue.add('-');
        int res = 1;
        for(int i = N; i >= 1; i++) {
            while (queue.isEmpty()) {
                queue.add('*');
                queue.add('/');
                queue.add('+');
                queue.add('-');
            }
            while (!queue.isEmpty()) {
                Character ope = queue.poll();
                if(ope == '*') {
                    res = res*i;
                } else if(ope == '/') {
                    res = res/i;
                } else if(ope == '+') {
                    res = res+i;
                } else if(ope == '-') {
                    res = res-i;
                }
            }
        }

        return 0;
    }

    /**
     * 263. 丑数
     * @param n
     * @return
     */
    public boolean isUgly(int n) {
        while (n/2 != 1 || n/3 != 1 || n/5 != 1) {
            if(n == 1) {
                return true;
            }
            if(n%2 == 0) {
                n = n/2;
            } else if(n%3 == 0) {
                n = n/3;
            } else if(n%5 == 0) {
                n = n/5;
            } else {
                return false;
            }
        }
        return true;
    }

    public boolean isUgly_offical(int n) {
        if (n <= 0) {
            return false;
        }
        int[] factors = {2, 3, 5};
        for (int factor : factors) {
            while (n % factor == 0) {
                n /= factor;
            }
        }
        return n == 1;
    }

    public static void main(String[] args) {
        Test test = new Test();
        System.out.println(test.isUgly(14));
    }
}
