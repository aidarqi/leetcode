package com.aidar.tree;

import java.util.*;

public class TreeTest {


    /**
     * 100. 相同的树
     *
     * @param p
     * @param q
     * @return
     */
    public boolean isSameTree(TreeNode p, TreeNode q) {
        StringBuffer pStr = new StringBuffer();
        traversalTree(p, pStr);
        StringBuffer qStr = new StringBuffer();
        traversalTree(q, qStr);
        return pStr.toString().equals(qStr.toString());
    }

    private void traversalTree(TreeNode p, StringBuffer str) {
        if (p == null) {
            return;
        }
        if (p.left == null && p.right == null) {
            str.append(p.val);
            return;
        }
        str.append(p.val);
        if (p.left != null) {
            traversalTree(p.left, str);
        } else {
            str.append("null");
        }
        if (p.right != null) {
            traversalTree(p.right, str);
        }
    }

    /**
     * 103. 二叉树的锯齿形层序遍历
     * @param root
     * @return
     */
    public List<List<Integer>> zigzagLevelOrder(TreeNode root) {
        List<List<Integer>> res = new ArrayList<>();
        boolean left2Right = true;
        Stack<TreeNode> stack = new Stack<>();
        if(root != null) {
            stack.push(root);
        } else {
            return res;
        }
        while (!stack.isEmpty()) {
            List<Integer> layer = new ArrayList<>();
            Stack<TreeNode> nextStack = new Stack<>();
            while(!stack.isEmpty())  {
                TreeNode node = stack.pop();
                layer.add(node.val);
                if (left2Right) {
                    if (node.left != null) {
                        nextStack.push(node.left);
                    }
                    if (node.right != null) {
                        nextStack.push(node.right);
                    }
                } else {
                    if (node.right != null) {
                        nextStack.push(node.right);
                    }
                    if (node.left != null) {
                        nextStack.push(node.left);
                    }
                }
            }
            stack = nextStack;
            res.add(layer);
            left2Right = !left2Right;
        }
        return res;
    }

    /**
     * 剑指 Offer 32 - I. 从上到下打印二叉树
     * @param root
     * @return
     */
    public int[] levelOrder(TreeNode root) {
        int[] res = new int[]{};
        List<Integer> resList = new ArrayList<>();
        List<TreeNode> list = new ArrayList<>();
        if(null == root) {
            return res;
        }
        list.add(root);
        while(list.size() != 0) {
            List<TreeNode> newList = new ArrayList<>();
            for(TreeNode node : list) {
                resList.add(node.val);
                if (node.left != null) newList.add(node.left);
                if (node.right != null) newList.add(node.right);
            }
            list = newList;
        }
        res = new int[resList.size()];
        for(int i = 0; i < resList.size(); i++) {
            res[i] = resList.get(i);
        }
        return res;
    }

    /**
     * 96. 不同的二叉搜索树
     * @param n
     * @return
     */
    public int numTrees(int n) {
        int[] arrs = new int[n];
        for(int i = 0; i < n; i++)  {
            arrs[i] = i+1;
        }
        return buildTree(arrs);
    }

    private int buildTree(int[] arrs) {
        if(arrs.length <= 2) {
            return arrs.length;
        }
        int len = arrs.length;
        int leftLen = 1;
        int rightLen = 1;
        int max = 0;
        for(int i = 0; i < len; i++)  {
            if(i > 0) {
                leftLen = buildTree(Arrays.copyOfRange(arrs, 0, i));
            }
            if(i + 1 < len) {
                rightLen = buildTree(Arrays.copyOfRange(arrs, i+1, len));
            }
            max += leftLen*rightLen;
        }
        return max;
    }

    public int numTrees1(int n) {
        int[] arrs = new int[n];
        int[] note = new int[n+1];
        note[1] = 1;
        note[2] = 2;
        for(int i = 0; i < n; i++)  {
            arrs[i] = i+1;
        }
        return buildTree1(arrs, note);
    }

    private int buildTree1(int[] arrs, int[] note) {
        if(arrs.length <= 2) {
            return arrs.length;
        }
        int len = arrs.length;
        int leftLen = 1;
        int rightLen = 1;
        int max = 0;
        for(int i = 0; i < len; i++)  {
            if(i > 0) {
                if(note[i-1] != 0 ) {
                    leftLen = note[i-1];
                } else {
                    leftLen = buildTree1(Arrays.copyOfRange(arrs, 0, i), note);
                    note[i-1] = leftLen;
                }
            }
            if(i + 1 < len) {
                if(note[i+1] != 0) {
                    rightLen = note[i+1];
                } else {
                    rightLen = buildTree1(Arrays.copyOfRange(arrs, i+1, len), note);
                    note[i+1] = rightLen;
                }
            }
            max += leftLen*rightLen;
        }
        return max;
    }

    public int numTrees2(int n) {
        int[] dp = new int[n+1];
        dp[0] = dp[1] = 1;
        for(int i = 2; i <= n; i++)  {
            for(int j = 1; j <=i; j++){
                dp[i] += dp[j - 1] * dp[i-j];
            }
        }
        return dp[n];
    }

    /**
     * 95. 不同的二叉搜索树 II
     * @param n
     * @return
     */
    public List<TreeNode> generateTrees(int n) {
        if (n == 0) {
            return new ArrayList<>();
        }
        return generateTrees(1, n);
    }

    private List<TreeNode> generateTrees(int left, int right) {
        List<TreeNode> all = new ArrayList<>();
        if (left > right) {
            all.add(null);
            return all;
        }
        for(int i = left; i <= right; i++) {
            List<TreeNode> leftTrees = generateTrees(left, i - 1);
            List<TreeNode> rightTrees = generateTrees(i + 1, right);
            for(TreeNode leftTree : leftTrees) {
                for(TreeNode rightTree : rightTrees) {
                    TreeNode root = new TreeNode(i);
                    root.left = leftTree;
                    root.right = rightTree;
                    all.add(root);
                }
            }
        }
        return all;
    }



    /**
     * 99. 恢复二叉搜索树
     * @param root
     */
    TreeNode t1, t2, pre;
    public void recoverTree(TreeNode root) {
        inorder(root);
        int temp = t1.val;
        t1.val = t2.val;
        t2.val = temp;
    }

    public void inorder(TreeNode root){
        if (root == null) return ;
        inorder(root.left);
        if (pre != null && pre.val > root.val) {
            if (t1 == null) t1 = pre;
            t2 = root;
        }
        pre = root;
        inorder(root.right);
    }

    /**
     * 106. 从中序与后序遍历序列构造二叉树
     * @param inorder
     * @param postorder
     * @return
     */
    public TreeNode buildTree(int[] inorder, int[] postorder) {
        if(inorder.length == 0) {
            return null;
        }
        if(inorder.length == 1) {
            return new TreeNode(inorder[0]);
        }
        Map<Integer, Integer> inMap = new HashMap<>();
        for(int i = 0; i < inorder.length; i++) {
            inMap.put(inorder[i], i);
        }
        int val = postorder[postorder.length-1];
        TreeNode root = new TreeNode(val);
        if (inMap.get(val) > 0) {
            root.left = buildTree(Arrays.copyOfRange(inorder,0, inMap.get(val)), Arrays.copyOfRange(postorder,0, inMap.get(val)));
        }
        if(inMap.get(val) + 1 < inorder.length) {
            root.right = buildTree(Arrays.copyOfRange(inorder,inMap.get(val)+1, inorder.length), Arrays.copyOfRange(postorder,inMap.get(val), postorder.length-1));
        }
        return root;
    }

    Map<Integer, Integer> inMap = new HashMap<>();
    int postIndex = 0;
    int[] inorder;
    int[] postorder;
    public TreeNode buildTree_1(int[] inorder, int[] postorder) {
        this.inorder = inorder;
        this.postorder = postorder;
        for(int i = 0; i < inorder.length; i++) {
            inMap.put(inorder[i], i);
        }
        postIndex = postorder.length - 1;
        return helper(0, inorder.length - 1);
    }
    private TreeNode helper(int left, int right){
        if(left > right) {
            return null;
        }
        int val = postorder[postIndex];
        TreeNode root = new TreeNode(val);
        postIndex--;
        root.right = helper(inMap.get(val) + 1, right);
        root.left = helper(left, inMap.get(val) - 1);
        return root;
    }



    /**
     * 105. 从前序与中序遍历序列构造二叉树
     * @param preorder
     * @param inorder
     * @return
     */
    public TreeNode buildTree105(int[] preorder, int[] inorder) {
        Map<Integer, Integer> map = new HashMap<>();
        for(int i = 0; i < inorder.length; i++) {
            map.put(inorder[i], i);
        }
        return buildTree(preorder, 0, preorder.length-1, inorder, 0, inorder.length-1, map);
    }

    private TreeNode buildTree(int[] preorder, int preStart, int preEnd, int[] inorder, int inStart, int inEnd, Map<Integer, Integer> inMap) {
        if(preStart > preEnd ||inStart > inEnd) {
            return null;
        }
        TreeNode root = new TreeNode(preorder[preStart]);
        int inRoot = inMap.get(root.val);
        int numsLeft = inRoot - inStart;
        root.left = buildTree(preorder, preStart+1, preStart+numsLeft,
                inorder, inStart, inRoot - 1, inMap);
        root.right = buildTree(preorder, preStart+numsLeft+1, preEnd,
                inorder, inRoot+1, inEnd, inMap);
        return root;
    }


    /**
     * 783. 二叉搜索树节点最小距离
     * 官方解答很优美
     * @param root
     * @return
     */
    public int minDiffInBST(TreeNode root) {
        List<Integer> list = new ArrayList<>();
        inOrder(root, list);
        int min = Integer.MAX_VALUE;
        for (int i = 1; i < list.size(); i++) {
            int diff = Math.abs(list.get(i) - list.get(i - 1));
            if(diff < min) {
                min = diff;
            }
        }
        return min;
    }

    public void inOrder(TreeNode root, List<Integer> list) {
        if(root == null) {
            return;
        }
        inOrder(root.left, list);
        list.add(root.val);
        //官方解答，在遍历过程中直接判断
//        if (pre == -1) {
//            pre = root.val;
//        } else {
//            ans = Math.min(ans, root.val - pre);
//            pre = root.val;
//        }
        inOrder(root.right, list);
    }

    /**
     * 897. 递增顺序搜索树
     * @param root
     * @return
     */
//    public TreeNode increasingBST(TreeNode root) {
////        if()
//    }

    /**
     * 938. 二叉搜索树的范围和
     * @param root
     * @param low
     * @param high
     * @return
     */

//    int res = 0;
//    public int rangeSumBST(TreeNode root, int low, int high) {
//        if(root == null) {
//            return 0;
//        }
//        if(root.val > high) {
//            rangeSumBST(root.left, low, high);
//        }
//        if(root.val < low) {
//            rangeSumBST(root.right, low, high);
//        }
//
//        if(root.val >= low && root.val <= high) {
//            rangeSumBST(root.left, low, high);
//            res += root.val;
//            rangeSumBST(root.right, low, high);
//        }
//        return res;
//    }

    public int rangeSumBST(TreeNode root, int low, int high) {
        if (root == null) {
            return 0;
        }
        if (root.val > high) {
            return rangeSumBST(root.left, low, high);
        }
        if (root.val < low) {
            return rangeSumBST(root.right, low, high);
        }
        return root.val + rangeSumBST(root.left, low, high) + rangeSumBST(root.right, low, high);
    }


    /**
     * 72. 叶子相似的树
     * @param root1
     * @param root2
     * @return
     */
    public boolean leafSimilar(TreeNode root1, TreeNode root2) {
        List<Integer> seq1 = new ArrayList<Integer>();
        if (root1 != null) {
            dfs(root1, seq1);
        }

        List<Integer> seq2 = new ArrayList<Integer>();
        if (root2 != null) {
            dfs(root2, seq2);
        }

        return seq1.equals(seq2);
    }

    private void dfs(TreeNode node, List<Integer> seq) {
        if (node.left == null && node.right == null) {
            seq.add(node.val);
        } else {
            if (node.left != null) {
                dfs(node.left, seq);
            }
            if (node.right != null) {
                dfs(node.right, seq);
            }
        }
    }

    /**
     * 993. 二叉树的堂兄弟节点
     * @param root
     * @param x
     * @param y
     * @return
     */
    // x 的信息
    int x;
    TreeNode xParent;
    int xDepth;
    boolean xFound = false;

    // y 的信息
    int y;
    TreeNode yParent;
    int yDepth;
    boolean yFound = false;

    public boolean isCousins(TreeNode root, int x, int y) {
        this.x = x;
        this.y = y;
        isCousinsDFS(root, 0, null);
        return xDepth == yDepth && xParent != yParent;
    }

    public void isCousinsDFS(TreeNode node, int depth, TreeNode parent) {
        if(node == null) {
            return;
        }

        if(node.val == x) {
            xParent = parent;
            xDepth = depth;
            xFound = true;
        } else if(node.val == y) {
            yParent = parent;
            yDepth = depth;
            yFound = true;
        }

        if(xFound && yFound) {
            return;
        }

        isCousinsDFS(node.left, depth + 1, node);

        if(xFound && yFound) {
            return;
        }
        isCousinsDFS(node.right, depth + 1, node);
    }


    public static void main(String[] args) {
//        TreeNode top1  = new TreeNode(1);
////        TreeNode left1 = new TreeNode(2);
//        TreeNode right1 = new TreeNode(3);
//
//        top1.left = right1;
//        TreeTest test = new TreeTest();
////        TreeNode a =  new TreeNode(1, new TreeNode(2), new TreeNode(3));
//        StringBuffer str = new StringBuffer();
//        test.traversalTree(top1, str);
//        System.out.println(str.toString());
//        List<Integer> list = new ArrayList<>();
//        list.add(1);
//        list.add(2);
//        list.add(3);
//        for(Integer i : list) {
//            System.out.println(i);
//            list.remove(i);
//        }
        TreeTest test = new TreeTest();
//        System.out.println(test.numTrees1(5));
        System.out.println(test.buildTree_1(new int[]{9,3,15,20,7}, new int[]{9,15,7,20,3}));

    }
}
