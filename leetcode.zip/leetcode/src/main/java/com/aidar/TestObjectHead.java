package com.aidar;

import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.ReentrantLock;

public class TestObjectHead {

    public static void main(String[] args) {
        AtomicInteger atomicInteger = new AtomicInteger();  // 需要保证多个线程使用的是同一个AtomicInteger
        atomicInteger.incrementAndGet();

        ReentrantLock lock = new ReentrantLock();
        lock.lock();
    }
}
