package com.aidar.linked;

import java.util.*;

public class Test {

    /**
     * 92. 反转链表 II
     * @param head
     * @param left
     * @param right
     * @return
     */
    public ListNode reverseBetween(ListNode head, int left, int right) {
        if(left == right) {
            return head;
        }
        Stack<ListNode> stack = new Stack<>();
        ListNode leftNode = null;
        ListNode rightNode =  null;
        int count = 1;
        ListNode tmp = head;
        ListNode newHead = null;
        while (null != tmp) {
            if(count < left) {
                leftNode = tmp;
            } else if(count >= left && count <= right) {
                stack.push(new ListNode(tmp.val));
            } else if(count > right) {
                rightNode = tmp;
                break;
            }
            tmp = tmp.next;
            count++;
        }
        if(null == leftNode) {
            newHead = stack.pop();
            tmp = newHead;
        } else {
            newHead = head;
            tmp = leftNode;
        }
        while (!stack.isEmpty()) {
            tmp.next = stack.pop();
            tmp = tmp.next;
        }
        tmp.next = rightNode;
        return newHead;
    }

    public ListNode reverseBetween1(ListNode head, int left, int right) {
        if(left == right) {
            return head;
        }
        Queue<ListNode> pre = new LinkedList<>();
        Queue<ListNode> bak = new LinkedList<>();
        Stack<ListNode> stack = new Stack<>();
        int count = 1;
        ListNode tmp = head;
        ListNode newHead = null;
        while (null != tmp) {
            if(count < left) {
                pre.add(new ListNode(tmp.val));
            } else if(count >= left && count <= right) {
                stack.push(new ListNode(tmp.val));
            } else if(count > right) {
                bak.add(new ListNode(tmp.val));
            }
            tmp = tmp.next;
            count++;
        }

        if(!pre.isEmpty()) {
            newHead = pre.poll();
        } else {
            newHead = stack.pop();
        }
        tmp = newHead;
        while (!pre.isEmpty()) {
            tmp.next = pre.poll();
            tmp = tmp.next;
        }
        while (!stack.isEmpty()) {
            tmp.next = stack.pop();
            tmp = tmp.next;
        }
        while (!bak.isEmpty()) {
            tmp.next = bak.poll();
            tmp = tmp.next;
        }
        tmp.next = null;
        return newHead;
    }

    public ListNode reverseBetween_offical(ListNode head, int left, int right) {
        ListNode dummyNode = new ListNode(-1);
        dummyNode.next = head;
        ListNode pre = dummyNode;
        for(int i = 1; i < left ; i++) {
            pre = pre.next;
        }

        ListNode rightNode = pre.next;
        for(int i = left; i < right; i++) {
            rightNode = rightNode.next ;
        }
        ListNode leftNode = pre.next;
        ListNode succ = rightNode.next;

        pre.next = null;
        rightNode.next = null;

        reverseLinkedList(leftNode);
        pre.next = rightNode;
        leftNode.next = succ;

        return dummyNode.next;
    }


    private void reverseLinkedList(ListNode head) {
        ListNode pre = null;
        ListNode cur = head;
        while (null != cur) {
            ListNode next = cur.next;
            cur.next = pre;
            pre = cur;
            cur = next;
        }
    }
    /**
     * 将权限转换为带有子级的权限对象
     * 当找不到子级权限的时候map操作不会再递归调用covert
     */
//    private UmsPermissionNode covert(UmsPermission permission, List<UmsPermission> permissionList) {
//        UmsPermissionNode node = new UmsPermissionNode();
//        BeanUtils.copyProperties(permission, node);
//        List<UmsPermissionNode> children = permissionList.stream()
//                .filter(subPermission -> subPermission.getPid().equals(permission.getId()))
//                .map(subPermission -> covert(subPermission, permissionList)).collect(Collectors.toList());
//        node.setChildren(children);
//        return node;
//    }

}
