package com.aidar.threadTest;

import java.util.concurrent.*;

public class Test {
    public static void main(String[] args) {
        ThreadPoolExecutor pool = new ThreadPoolExecutor(1, 2, 1000, TimeUnit.MILLISECONDS, new LinkedBlockingQueue<Runnable>());
        pool.execute(new Runnable() {
            @Override
            public void run() {
                System.out.println(".....");
            }
        });
    }
}
