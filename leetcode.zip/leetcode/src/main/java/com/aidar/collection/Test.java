package com.aidar.collection;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FilterInputStream;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

public class Test {
    public static void main(String[] args) throws Exception {
        HashMap<String, String> map = new HashMap<>();
        map.put("1", "3");
//        map.put(null, "3");
//        map.put(null, "4");
        System.out.println(map.get("210"));
        ConcurrentHashMap<String, String> conMap = new ConcurrentHashMap<>();
        conMap.put("1", "3");


        HashSet<Object> set= new HashSet<>();
        Object o = new Object();
        Object o1 = new Object();
        set.add(o);
        set.add(o1);
        System.out.println(set);

        String pathname = "home/upsmart/input.txt";
        File filename = new File(pathname);
        BufferedInputStream bis = new BufferedInputStream(new FileInputStream(filename));

        List simpleList = List.of("Hello","world","world");

        Collections.synchronizedMap(map);

    }
}
