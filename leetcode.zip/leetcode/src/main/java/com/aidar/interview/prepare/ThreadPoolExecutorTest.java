package com.aidar.interview.prepare;

import java.util.concurrent.*;

public class ThreadPoolExecutorTest {
    public static void main(String[] args) throws InterruptedException{
//        BlockingQueue queue = new ArrayBlockingQueue(3);
        BlockingQueue queue = new LinkedBlockingQueue();
//        BlockingQueue queue = new SynchronousQueue();
        ThreadPoolExecutor executor = new ThreadPoolExecutor(4,
                8,
                30,
                TimeUnit.SECONDS,
                queue,
//                new ThreadPoolExecutor.CallerRunsPolicy());
                new ThreadPoolExecutor.DiscardPolicy());
//        executor.allowCoreThreadTimeOut(true);
        for (int k = 0; k < 100; k++) {
            Task task = new Task(k);
            executor.execute(task);
        }
        System.out.println("poorSize " + executor.getPoolSize());
        Thread.sleep(40 * 1000);
        System.out.println("poorSize after sleep " + executor.getPoolSize());
    }

    private static class Task implements Runnable {
        private int i;

        public Task(int i) {
            this.i = i;
        }

        @Override
        public void run() {
            for (int k = 0; k < 10; k++) {
                System.out.println(Thread.currentThread().getName() + " " + i + " >>> " + k);
            }
        }
    }
}
