package com.aidar.interview.prepare;

import java.util.Queue;
import java.util.concurrent.*;

public class QueueTest {
    public static void main(String[] args) throws InterruptedException {
        ConcurrentLinkedQueue queue = new ConcurrentLinkedQueue();
        ConcurrentLinkedDeque<Integer> concurrentLinkedDeque = new ConcurrentLinkedDeque();
        concurrentLinkedDeque.addLast(1);
        concurrentLinkedDeque.offerLast(1);
        LinkedBlockingDeque<Integer> linkedBlockingDeque = new LinkedBlockingDeque<>();
        linkedBlockingDeque.addLast(1);
        linkedBlockingDeque.offerLast(1);

        BlockingQueue linkedBlockingQueue = new LinkedBlockingQueue();
        linkedBlockingQueue.take();
        BlockingQueue arrayBlockingQueue = new ArrayBlockingQueue(10);
        CopyOnWriteArrayList copyOnWriteArrayList = new CopyOnWriteArrayList();
    }
}
