package com.aidar.interview.prepare;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class ArrayTest {
    /**
     * [3,2,1,-1,-2,-3]
     * @param arr
     * @return
     */
    public Integer[] sortArr(Integer[] arr) {
        Arrays.sort(arr, new Comparator<>() {
            @Override
            public int compare(Integer o1, Integer o2) {
                if(o1 < 0 && o2 < 0) {
                    return Math.abs(o1) - Math.abs(o2);
                } else {
                    return o2 - o1;
                }
            }
        });
        return arr;
    }

    /**
     * 240. 搜索二维矩阵 II
     *
     * @param matrix
     * @param target
     * @return
     */
    public boolean searchMatrix2(int[][] matrix, int target) {
        return false;
    }

    public static void main(String[] args) {
        ArrayTest test = new ArrayTest();
        test.sortArr(new Integer[]{-1,1,2,1, -3, -2});

    }
}
