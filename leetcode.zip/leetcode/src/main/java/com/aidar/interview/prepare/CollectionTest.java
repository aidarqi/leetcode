package com.aidar.interview.prepare;

import java.util.ArrayList;
import java.util.List;

public class CollectionTest {

    public static void main(String[] args) {
        List<Integer> numList = new ArrayList<>();
        for(int i = 0; i < 10; i++) {
            numList.add(i);
        }
//        for(int i = 0; i < numList.size(); i++) {
//            numList.set(i, 10);
//        }
//
//        for(int i = 0; i < numList.size(); i++) {
//            System.out.println(numList.get(i));
//        }
        for(Integer num : numList) {
            num = 10;
        }

        for(int i = 0; i < numList.size(); i++) {
            System.out.println(numList.get(i));
        }
    }
}
