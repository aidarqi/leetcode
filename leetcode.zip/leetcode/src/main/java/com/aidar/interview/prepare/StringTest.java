package com.aidar.interview.prepare;
import java.math.BigDecimal;
public class StringTest {

    public String add(String s1, String s2) {
//        BigDecimal bd1 = new BigDecimal(s1);
//        BigDecimal bd2 = new BigDecimal(s2);
//        return String.valueOf(bd1.add(bd2));
        String[] s1Arr = s1.split("\\.");
        String[] s2Arr = s2.split("\\.");
        StringBuilder sb1 = new StringBuilder(s1Arr[0]).reverse();
        StringBuilder sb2 = new StringBuilder(s2Arr[0]).reverse();
        StringBuilder sbDec1 = new StringBuilder(s1Arr[1]).reverse();
        StringBuilder sbDec2 = new StringBuilder(s2Arr[1]).reverse();
        StringBuilder[] decRes = addString(sbDec1, sbDec2, 0, true);
        StringBuilder[] intRes = addString(sb1, sb2, Integer.valueOf(decRes[1].toString()), false);
        StringBuilder res = intRes[0].reverse().append(".").append(decRes[0].reverse());
        if(!intRes[1].toString().equals("0")) {
            res.insert(0, intRes[1]);
        }
        return res.toString();
    }

    private StringBuilder[] addString(StringBuilder s1, StringBuilder s2, int plus, boolean flag) {
        StringBuilder sb = new StringBuilder();
        int len1 = s1.length();
        int len2 = s2.length();
        int maxLen = Integer.max(len1, len2);
        if(len1 < maxLen){
            for(int i = len1; i < maxLen; i++) {
                if(flag) {
                    s1.insert(0, "0");
                } else {
                    s1.append("0");
                }
            }
        }
        if(len2 < maxLen){
            for(int i = len2; i < maxLen; i++) {
                if(flag) {
                    s2.insert(0, "0");
                } else {
                    s2.append("0");
                }
            }
        }
        for (int i = 0; i < maxLen; i++) {
            int item1 = Integer.parseInt(String.valueOf(s1.charAt(i)));
            int item2 = Integer.parseInt(String.valueOf(s2.charAt(i)));
            int sum = item1 + item2 + plus;
            plus = sum/10;
            int remainder = sum % 10;
            sb.append(remainder);
        }
        StringBuilder[] res = new StringBuilder[2];
        res[0] = sb;
        res[1] = new StringBuilder(String.valueOf(plus));
        return res;
    }


    public static void main(String[] args) {
        StringTest test = new StringTest();
//        System.out.println(test.add("9876543210987654321.01", "9876543210987654321.99"));
//        System.out.println(test.add("141.0", "99.0"));
        System.out.println(test.add("141.11", "99.99999"));
    }
}
