package com.aidar.interview.prepare;

public class ThreadTest {
    public static void main(String[] args) throws InterruptedException {

        Thread thread1 = new Thread(new Runnable() {
            @Override
            public void run() {
                for(int i = 0; i < 10; i++) {
                    System.out.println(Thread.currentThread().getName() + " " + String.valueOf(i));
                }
            }
        });

        Thread thread2 = new Thread(new Runnable() {
            @Override
            public void run() {
                for(int i = 10; i < 20; i++) {
                    System.out.println(Thread.currentThread().getName() + " " + String.valueOf(i));
                }
            }
        });

        Thread thread3 = new Thread(new Runnable() {
            @Override
            public void run() {
                for(int i = 20; i < 30; i++) {
                    System.out.println(Thread.currentThread().getName() + " " + String.valueOf(i));
                }
            }
        });

        thread1.start();
        thread1.join();
        thread2.start();
        thread2.join();
        thread3.start();
        thread3.join();
    }
}
