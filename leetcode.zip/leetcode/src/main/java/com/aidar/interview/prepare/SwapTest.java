package com.aidar.interview.prepare;

/**
 * 值传递: 基本类型都是值传递，
 * 类似的 String, Integer, Float, Double, Short, Byte, Long, Character等基本包装类型类。
 * 因为他们本身没有提供方法去改变内部的值，例如 Integer内部有一个 value 来记录 int基本类型的值，但是没有提供修改它的方法，而且 也是 final类型的，无法通过 常规手段更改。所以虽然他们是引用类型的，但是可以认为它是值传递,
 */
public class SwapTest {

    /**
     * 值传递
     * @param a
     * @param b
     */
    void swapInt(int a, int b) {
        int tmp = a;
        a = b;
        b = tmp;
        System.out.println("方法中交换值： " + a + "; " + b);
    }

    void swapInteger(Integer a, Integer b) {
        int tmp = a;
        a = b;
        b = tmp;
        System.out.println("方法中交换值： " + a + "; " + b);
    }


    public static void main(String[] args) {

        SwapTest test = new SwapTest();
        int a = 1, b =5;
        test.swapInt(a, b);
        System.out.println("交换值： " + a + "; " + b);
        a = 200;
        b = 1000;
        test.swapInt(a, b);
        System.out.println("交换值： " + a + "; " + b);
        a = Integer.valueOf(200);
        b = Integer.valueOf(1000);
        test.swapInteger(a, b);
        System.out.println("交换值： " + a + "; " + b);
        System.out.println("**********************************");
        a = 1;
        b = 1;
        System.out.println("a == b： " + (a == b));
        a = 200;
        b = 200;
        System.out.println("a == b： " + (a == b));
        a = 300;
        b = 300;
        System.out.println("a == b： " + (a == b));
        a = Integer.valueOf(300);
        b = 0+a;
        System.out.println("a == b： " + (a == b));
        String A1 = "A";
        String A2 = "A";
        System.out.println("A1 == A2： " + (A1 == A2));
        System.out.println("A1 equals A2： " + (A1.equals(A2)));
        A2 = "" + "A";
        System.out.println("A1 == A2： " + (A1 == A2));
        System.out.println("A1 equals A2： " + (A1.equals(A2)));
        A2 = "" + A1;
        System.out.println("A1 == A2： " + (A1 == A2));
        System.out.println("A1 equals A2： " + (A1.equals(A2)));

    }
}
