package com.aidar.microsoft;

import java.util.LinkedList;
import java.util.Queue;

/**
 * Please implement this function
 * bool is_match(string pattern, string str)
 * You are going to check if str matches pattern.
 * Pattern consists of lowercase Latin characters, and each of char may be followed by "{x,y}"
 * where x and y are non-negative integers and x<=y, meaning the character before it shall repeat from x to y(inclusive) times.
 * For example,
 * is_match("of{2,4}ice", "office")==True
 * is_match("bing{2,4}", "bing")==False
 */
public class Test {
    public boolean is_match(String pattern, String str) {
        int len = str.length();
        str += "#";
        Queue<Pattern> queue = convert(pattern);
        int i = 0;
        while (!queue.isEmpty() && i < str.length()) {
            Pattern item = queue.poll();
            int count = 1;
            while (i < str.length() - 1 && str.charAt(i+1) == str.charAt(i)) {
                i++;
                count++;
            }
            if(str.charAt(i) == item.alpha && item.min <= count && count<= item.max) {
                i++;
            } else {
                return false;
            }
        }
        return queue.isEmpty() && i == len;
    }

    public Queue<Pattern> convert(String pattern) {
        Pattern pre = null;
        Queue<Pattern> queue = new LinkedList<>();
        for(int i = 0; i < pattern.length(); i++) {
            char c = pattern.charAt(i);
            if(c != '{' && c != '}') {
                if(pre == null) {
                    pre = new Pattern(c, 1, 1);
                    continue;
                }
                if(pre.alpha != c) {
                    queue.add(pre);
                    pre = new Pattern(c, 1, 1);
                } else {
                    pre.min += 1;
                    pre.max += 1;
                }
            } else if(c == '{'){
                int j = i;
                while (pattern.charAt(j) != '}') {
                    j++;
                }
                String sub = pattern.substring(i+1, j);
                String[] strArr = sub.split(",");
                pre.min += Integer.valueOf(strArr[0]) - 1;
                pre.max += Integer.valueOf(strArr[1]) - 1;
                i = j;
            }
        }
        queue.add(pre);
        return queue;
    }
    class Pattern {
        char alpha;
        int min = 1;
        int max = 1;
        Pattern(char alpha, int min, int max) {
            this.alpha = alpha;
            this.min = min;
            this.max = max;
        }
    }

    public static void main(String[] args) {
        Test test = new Test();
        Queue<Pattern> queue = test.convert("of{2,4}ice");
        System.out.println(queue);
        Queue<Pattern> queue1 = test.convert("of{2,4}f{1,3}fice");
        System.out.println(queue1);
        Queue<Pattern> queue2 = test.convert("of{2,4}f{1,3}f");
        System.out.println(queue2);
        Queue<Pattern> queue3 = test.convert("f{2,4}f{1,3}fice");
        System.out.println(queue3);
        boolean flag = test.is_match("of{2,4}f{1,3}fice", "offffice");
        System.out.println(flag);
        System.out.println(test.is_match("of{2,4}ice", "office"));
        System.out.println(test.is_match("bing{2,4}", "bing"));
        System.out.println(test.is_match("of{2,4}f{1,3}f", "offff"));
    }
}
