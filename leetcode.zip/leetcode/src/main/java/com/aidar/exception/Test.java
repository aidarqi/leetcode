package com.aidar.exception;

public class Test {
    public int testException() {
        int i =0;
        try{
            i = 1/0;
            return 1;
        }catch(ArithmeticException e){
            e.printStackTrace();
            return i;
        }finally {
            System.out.println("finally语句执行-----2");
            i=1;
            return 3;
        }
    }

    public static void main(String[] args) {
        Test test = new Test();
        System.out.println(test.testException());
    }
}
