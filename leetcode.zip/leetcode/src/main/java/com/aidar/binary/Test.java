package com.aidar.binary;

public class Test {
    public int hammingWeight(int n) {
        int ret = 0;
        while (n != 0) {
            n &= n - 1;
            ret++;
        }
        return ret;
//        return Integer.bitCount(n);
    }

    public static void main(String[] args) {
        Test test = new Test();
        test.hammingWeight(6);
    }
}
