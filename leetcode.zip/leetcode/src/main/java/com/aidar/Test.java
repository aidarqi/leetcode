package com.aidar;

import com.aidar.tree.TreeNode;

import java.util.*;

public class Test{

    public String sortString(String s) {
        char[] arr = s.toCharArray();
        int len = arr.length;
        List<Character> keys = new ArrayList<Character>();
        HashMap<Character, Integer> map = new HashMap<Character, Integer>();
        for (Character c : arr) {
            if (!keys.contains(c)) {
                keys.add(c);
            }
            if (map.keySet().contains(c)) {
                int count = map.get(c);
                map.put(c, count + 1);
            } else {
                map.put(c, 1);
            }
        }
        Collections.sort(keys);

        boolean flag = true;
        int temp_index = 0;
        int key_len = keys.size();
        ArrayList<Character> result = new ArrayList<>();
        for (int i = 0; i < len; ) {
            if (flag) {
                for (int j = temp_index; j < key_len; j++) {
                    char key = keys.get(j);
                    int key_num = map.get(key);
                    if (key_num != 0) {
                        map.put(key, key_num - 1);
                        result.add(key);
                        i++;
                        temp_index = j + 1;
                        if (j == key_len - 1) {
                            flag = false;
                            temp_index = key_len - 1;
                        }
                        break;
                    }
                    if (j == key_len - 1) {
                        flag = false;
                        temp_index = key_len - 1;
                    }
                }
            } else {
                for (int j = temp_index; j >= 0; j--) {
                    char key = keys.get(j);
                    int key_num = map.get(key);
                    if (key_num != 0) {
                        map.put(key, key_num - 1);
                        result.add(key);
                        i++;
                        temp_index = j - 1;
                        if (j == 0) {
                            flag = true;
                            temp_index = 0;
                        }
                        break;
                    }

                    if (j == 0) {
                        flag = true;
                        temp_index = 0;
                    }
                }
            }
        }

        return result.stream().map(e -> e.toString()).reduce((acc, e) -> acc + e).get();

    }

    /**
     * 如果方格存在，'U' 意味着将我们的位置上移一行；
     * 如果方格存在，'D' 意味着将我们的位置下移一行；
     * 如果方格存在，'L' 意味着将我们的位置左移一列；
     * 如果方格存在，'R' 意味着将我们的位置右移一列；
     * '!' 会把在我们当前位置 (r, c) 的字符 board[r][c] 添加到答案中。
     * <p>
     * 来源：力扣（LeetCode）
     * 链接：https://leetcode-cn.com/problems/alphabet-board-path
     * 著作权归领扣网络所有。商业转载请联系官方授权，非商业转载请注明出处。
     *
     * @param target
     * @return
     */
    public String alphabetBoardPath(String target) {
//        String[] board ={"abcde", "fghij", "klmno", "pqrst", "uvwxy", "z"}
        char[][] board = {
                {'a', 'b', 'c', 'd', 'e'},
                {'f', 'g', 'h', 'i', 'j'},
                {'k', 'l', 'm', 'n', 'o'},
                {'p', 'q', 'r', 's', 't'},
                {'u', 'v', 'w', 'x', 'y'},
                {'z'}};
        int row = board.length;
        char[] aphabetArr = target.toCharArray();
        int[][] resultIndex = new int[aphabetArr.length + 1][2];
        resultIndex[0][0] = 0;
        resultIndex[0][1] = 0;

        for (int k = 0; k < aphabetArr.length; k++) {
            char c = aphabetArr[k];
            for (int rowIndex = 0; rowIndex < row; rowIndex++) {
                int col = board[rowIndex].length;
                if (c <= board[rowIndex][col - 1]) {
                    for (int colIndex = 0; colIndex < col; colIndex++) {
                        if (board[rowIndex][colIndex] == c) {
                            resultIndex[k + 1][0] = rowIndex;
                            resultIndex[k + 1][1] = colIndex;
                        }
                    }
                }
            }
        }

        StringBuilder result = new StringBuilder();
        char operation = 'U';
        for (int k = 1; k < resultIndex.length; k++) {
//            int[] previous_index = resultIndex[k-1];
            //上下移动
            int upDown = resultIndex[k][0] - resultIndex[k - 1][0];
            int leftRight = resultIndex[k][1] - resultIndex[k - 1][1];

            if (upDown > 0) {
                operation = 'D';
            } else {
                operation = 'U';
            }
            for (int i = 0; i < Math.abs(upDown); i++) {
                result.append(operation);
            }
            if (leftRight > 0) {
                operation = 'R';
            } else {
                operation = 'L';
            }

            if (resultIndex[k][0] == row - 1 && leftRight != 0) {
                for (int i = 0; i < Math.abs(leftRight); i++) {
                    result.insert(result.length() - 1, operation);
                }
            } else {
                for (int i = 0; i < Math.abs(leftRight); i++) {
                    result.append(operation);
                }
            }

            if (upDown == 0 && leftRight == 0) {
                operation = '!';
                result.append(operation);
                continue;
            }
            result.append('!');
        }
        return result.toString();
    }

    public boolean isTransformable(String s, String t) {
//        ArrayList<String> tSubStr = new ArrayList<>();
//        int beginIndex= 0;
//        for(int i=beginIndex+1; i < t.length(); i++) {
//            if(t.charAt(i) < t.charAt(i-1)) {
//                tSubStr.add(t.substring(beginIndex, i));
//                beginIndex = i;
//            }
//        }
//
//        tSubStr.add(t.substring(beginIndex));
        Stack[] pos = new Stack[10];
        for (int i = 0; i < 10; i++) {
            pos[i] = new Stack<Integer>();
        }

        int len = s.length();
        for (int i = 0; i < len; i++) {
            pos[s.charAt(i) - '0'].add(i);
        }

        for (int i = len - 1; i >= 0; i--) {
            int c = t.charAt(i) - '0';
            if (pos[c].size() == 0) return false;
            int p = (int) pos[c].pop();
            for (int j = c + 1; j < 10; j++) {
                if (pos[j].size() > 0 && p < (int) pos[j].peek())
                    return false;
            }
        }
        return true;
    }

    public int islandPerimeter(int[][] grid) {
        int rowNum = grid.length;
        int colNum = grid[0].length;
        int num = 0;
        for (int i = 0; i < rowNum; i++) {
            for (int j = 0; j < colNum; j++) {
                if (grid[i][j] == 1) {
                    num += 4;
//                    if(i-1 >= 0 && grid[i-1][j] == 1) {
//                        num -= 1;
//                    }
//                    if(i+1 < rowNum && grid[i+1][j] == 1) {
//                        num -= 1;
//                    }
//                    if(j-1 >= 0 && grid[i][j-1] == 1) {
//                        num -= 1;
//                    }
//                    if(j+1 < colNum && grid[i][j+1] == 1) {
//                        num -= 1;
//                    }
                    if (i - 1 >= 0 && grid[i - 1][j] == 1) {
                        num -= 2;
                    }
                    if (j - 1 >= 0 && grid[i][j - 1] == 1) {
                        num -= 2;
                    }
                }
            }
        }
        return num;
    }

    /**
     * 885. 螺旋矩阵 III
     *
     * @param R
     * @param C
     * @param r0
     * @param c0
     * @return
     */
    public int[][] spiralMatrixIII(int R, int C, int r0, int c0) {
        int[][] result = new int[R * C][2];
        Queue<String> queue = new LinkedList<String>();
        int step = 0;
        for (int i = 0; i < R * C; ) {
            if (queue.isEmpty()) {
                queue.add("RIGHT");
                queue.add("DOWN");
                queue.add("LEFT");
                queue.add("UP");
            }
            while (!queue.isEmpty()) {
                String operation = queue.poll();
                if (operation == "RIGHT") {
                    c0 += step + 1;
                }
                if (operation == "DOWN") {
                    r0 += step + 1;
                }
                if (operation == "LEFT") {
                    c0 -= step + 2;
                }
                if (operation == "UP") {
                    r0 -= step + 2;
                }
                i++;
            }
            step = step + 2;
        }
        return result;
    }

    /**
     * 659. 分割数组为连续子序列
     * hashmap + 最小堆
     *
     * @param nums
     * @return
     */
    public boolean isPossible(int[] nums) {
        Map<Integer, PriorityQueue<Integer>> res = new HashMap<>();
        for (int num : nums) {
            if (!res.containsKey(num)) {
                res.put(num, new PriorityQueue<Integer>());
            }
            if (res.containsKey(num - 1)) {
                int prevLength = res.get(num - 1).poll();
                if (res.get(num - 1).isEmpty()) {
                    res.remove(num - 1);
                }
                res.get(num - 1).offer(prevLength + 1);
            } else {
                res.get(num).offer(1);
            }
        }
        for (Queue<Integer> value : res.values()) {
            if (value.peek() < 3) {
                return false;
            }
        }

        return true;
    }

    /**
     * 659. 分割数组为连续子序列
     * 贪心，两个hashmap
     *
     * @param nums
     * @return
     */
    public boolean isPossible1(int[] nums) {
        Map<Integer, Integer> countMap = new HashMap<>();
        for (int num : nums) {
            if (!countMap.containsKey(num)) {
                countMap.put(num, 1);
            } else {
                int prevCount = countMap.get(num);
                countMap.put(num, prevCount + 1);
            }
        }
        Map<Integer, Integer> res = new HashMap<>();
        for (int num : nums) {
            int count = countMap.getOrDefault(num, 0);
            if (count > 0) {
                countMap.put(num, count - 1);
                int prevCount = res.getOrDefault(num - 1, 0);
                if (prevCount > 0) {
                    res.put(num - 1, prevCount - 1);
                    res.put(num, res.getOrDefault(num, 0) + 1);
                } else {
                    if (countMap.getOrDefault(num + 1, 0) > 0 && countMap.getOrDefault(num + 2, 0) > 0) {
                        res.put(num + 2, res.getOrDefault(num + 2, 0) + 1);
                        countMap.put(num + 1, countMap.get(num + 1) - 1);
                        countMap.put(num + 2, countMap.get(num + 2) - 1);
                    } else {
                        return false;
                    }
                }
            }
        }
        return true;
    }

    public List<Integer> splitIntoFibonacci(String S) {
        List<Integer> res = new ArrayList<>();
        backtrack(res, S.toCharArray(), 0);
        return res;
    }

    private boolean backtrack(List<Integer> res, char[] arr, int start) {
        //终止条件(递归必须要有终止条件)
        if (start == arr.length && res.size() > 2) {
            //一些逻辑操作（可有可无，视情况而定）
            return true;
        }

        for (int i = start; i < arr.length; i++) {
            if (arr[start] == '0' && i > start) {
                break;
            }
            StringBuilder str = new StringBuilder();
            for (int j = start; j <= i; j++) {
                str.append(arr[j]);
            }
            int strInt = 0;
            try {
                strInt = Integer.parseInt(str.toString());
            } catch (NumberFormatException e) {
                e.printStackTrace();
                break;
            }
//            if(res.size() >=2 && strInt == res.get(res.size()-1) + res.get(res.size()-2)) {
//                res.add(strInt);
//            }
//            if(res.size() < 2) {
//                res.add(strInt);
//            }
            if (res.size() >= 2 && strInt > res.get(res.size() - 1) + res.get(res.size() - 2)) {
                break;
            }
            if (res.size() < 2 || strInt == res.get(res.size() - 1) + res.get(res.size() - 2)) {
                res.add(strInt);
                //一些逻辑操作（可有可无，视情况而定）
                //做出选择

                //递归
                if (backtrack(res, arr, i + 1)) {
                    return true;
                }
                ;
                //一些逻辑操作（可有可无，视情况而定）

                //撤销选择
                res.remove(res.size() - 1);
            }
        }
        return false;
    }

    public boolean lemonadeChange(int[] bills) {
        int[] store = new int[3];
        for (int b : bills) {
            if (b == 5) {
                store[0] += 1;
            }
            if (b == 10) {
                if (store[0] > 0) {
                    store[0] -= 1;
                    store[1] += 1;
                } else {
                    return false;
                }
            }
            if (b == 20) {
                if (store[1] > 0 && store[0] > 0) {
                    store[0] -= 1;
                    store[1] -= 1;
                    store[2] += 1;
                } else if (store[0] > 2) {
                    store[0] -= 3;
                    store[2] += 1;
                } else {
                    return false;
                }
            }
        }
        return true;
    }

    public String predictPartyVictory(String senate) {
        List<Character> chars = new ArrayList<>();
        for (int i = 0; i < senate.length(); i++) {
            chars.add(senate.charAt(i));
        }
        List<Character> res = getResult(chars);
        if(res.contains('R')) {
            return "Radiant";
        } else {
            return "Dire";
        }
    }

    public List<Character> getResult(List<Character> chars) {
        Set<Character> set =  new HashSet<>();
        for(char c : chars) {
            set.add(c);
        }
        if (set.size() == 1) {
            return chars;
        }
        for (int i = 0; i < chars.size(); i++) {
            if (chars.get(i) != null) {
                boolean flag = true;
                for (int j = i+1; j < chars.size(); j++) {
                    if (chars.get(j) != null && chars.get(i) != chars.get(j)) {
                        chars.set(j, null);
                        flag = false;
                        break;
                    }
                }
                if (flag) {
                    for (int j = i - 1; j >= 0; j--) {
                        if (chars.get(j) != null && chars.get(i) != chars.get(j)) {
                            chars.set(j, null);
                            break;
                        }
                    }
                }
            }
        }
        List<Character> res = new ArrayList<>();
        for (int i = 0; i < chars.size(); i++) {
            if (chars.get(i) != null) {
                res.add(chars.get(i));
            }
        }
        return getResult(res);
    }

    public String predictPartyVictory1(String senate) {
        int len = senate.length();
        Queue<Integer> Radiant = new LinkedList<>();
        Queue<Integer> Dire = new LinkedList<>();
        for (int i = 0; i < senate.length(); i++) {
            if(senate.charAt(i) == 'R') {
                Radiant.offer(i);
            } else {
                Dire.offer(i);
            }
        }
        while (!Radiant.isEmpty() && !Dire.isEmpty()) {
            int r = Radiant.poll();
            int d = Dire.poll();
            if (r < d) {
                Radiant.offer(r + len);
            } else {
                Dire.offer(d + len);
            }
        }
        if (!Radiant.isEmpty()) {
            return "Radiant";
        } else {
            return "Dire";
        }
    }

//    public int lengthOfLongestSubstring(String s) {
//        HashMap<Character, Integer> map = new HashMap<>();
//        int longest = 0;
//        int prevEnd = -1;
//        for (int i = 0; i < s.length(); i++) {
//            int prevRepeatedEnd = map.getOrDefault(s.charAt(i), -1);
//            if(prevRepeatedEnd != -1) {
//                int prevLen = prevRepeatedEnd - prevEnd;
//                longest = prevLen > longest ? prevLen : longest;
//                int len = prevRepeatedEnd > prevEnd ? i - prevRepeatedEnd : i -prevEnd;
//                longest = len > longest ? len : longest;
//                prevEnd = prevRepeatedEnd;
//                map.put(s.charAt(i), i);
//            } else if(s.length() - 1 == i) {
//                int tempLen = i - prevEnd;
//                longest = tempLen > longest ? tempLen : longest;
//            } else {
//                map.put(s.charAt(i), i);
//            }
//        }
//        return longest;
//    }


    /**
     * 3. 无重复字符的最长子串
     * @param s
     * @return
     */
    public int lengthOfLongestSubstring(String s) {
        HashMap<Character, Integer> map = new HashMap<>();
        int longest = 0;
        int startIndex = 0;

        for (int i = 0; i < s.length(); i++) {
            int lastRepeatedIndex = map.getOrDefault(s.charAt(i), -1);
            if (lastRepeatedIndex != -1 && lastRepeatedIndex >= startIndex) {
                int len = i - startIndex;
                longest = len > longest ? len : longest;
                startIndex = lastRepeatedIndex + 1;
                map.put(s.charAt(i), i);
            } else if (s.length() - 1 == i) {
                int tempLen = i - startIndex + 1;
                longest = tempLen > longest ? tempLen : longest;
            } else {
                map.put(s.charAt(i), i);
            }
        }
        return longest;
    }

    /**
     * 49. 字母异位词分组
     * @param strs
     * @return
     */
    public List<List<String>> groupAnagrams(String[] strs) {
        List<List<String>> res = new ArrayList<>();
        String[] sortedStrs = new String[strs.length];
        for(int i = 0; i < strs.length; i++) {
            char[] arr = strs[i].toCharArray();
            Arrays.sort(arr);
            String sortedStr = String.valueOf(arr);
            sortedStrs[i] = sortedStr;
        }
        Map<String, List<String>> map = new HashMap<>();
        for (int i = 0; i < sortedStrs.length; i++) {
            String sortedStr = sortedStrs[i];
            List<String> list = map.getOrDefault(sortedStr, new ArrayList<>());
            list.add(strs[i]);
            map.put(sortedStr, list);
        }
        for(List<String> item : map.values()) {
            res.add(item);
        }
        return res;
    }

    /**
     * 738. 单调递增的数字
     * @param N
     * @return
     */
    public int monotoneIncreasingDigits(int N) {
        char[] arr = Integer.toString(N).toCharArray();
        int i = 1;
        while (i < arr.length && arr[i-1] <= arr[i]) {
            i++;
        }
        int j = i;
        if(i < arr.length) {
            while (j > 0 && arr[j-1] > arr[j]) {
                arr[j-1] -= 1;
                j--;
            }
        }
        for(int k = j+1; k < arr.length; k++) {
            arr[k] = '9';
        }
        return Integer.valueOf(new String(arr));
    }


    StringBuffer res = new StringBuffer();
    private String getIncreasingDigits(int[] arr, boolean flag) {
        // 高位已经减过值
        if (flag) {
            for (int i : arr) {
                res.append(9);
            }
            return res.toString();
        }

        if(arr.length == 1) {
            res.append(arr[0]);
            return res.toString();
        }

        int from = 1;
        if(arr[0] < arr[arr.length - 1]) {
            res.append(arr[0]);
        } else if(arr[0] == arr[arr.length - 1]) {
            boolean theSame = true;
            for(int i : arr) {
                if(i != arr[0]) {
                    theSame = false;
                }
            }
            if(theSame) {
                for (int i : arr) {
                    res.append(arr[0]);
                }
                return res.toString();
            } else {
                if (arr[0] - 1 > 0) {
                    res.append(arr[0] - 1);
                } else {
                    res.append(9);
                    from = 2;
                }
                flag = true;
            }
        } else {
            if (arr[0] - 1 > 0) {
                res.append(arr[0] - 1);
            } else {
                res.append(9);
                from = 2;
            }
            flag = true;
        }
        int[] resArr = Arrays.copyOfRange(arr, from, arr.length);
        return getIncreasingDigits(resArr, flag);
    }

    private int[] convertIntToArr(int N) {
        Stack<Integer> stack = new Stack<>();
        while (N/10 != 0) {
            stack.push(N%10);
            N = N/10;
        }
        stack.push(N);
        int[] arr = new int[stack.size()];
        for(int i = 0; i < arr.length; i++) {
            arr[i] = stack.pop();
        }
        return arr;
    }

    /**
     * 290. 单词规律
     * @param pattern
     * @param s
     * @return
     */
    public boolean wordPattern(String pattern, String s) {
        String[] arr = s.split(" ");
        if(pattern.length() != arr.length) {
            return false;
        }
        Map<Character, List<Integer>> patternMap = new HashMap<>();
        for(int i = 0; i < pattern.length();i++) {
            char item = pattern.charAt(i);
            if(patternMap.containsKey(item)) {
                List<Integer> value = patternMap.get(item);
                value.add(i);
                patternMap.put(item, value);
            } else {
                List<Integer> value = new ArrayList<>();
                value.add(i);
                patternMap.put(item, value);
            }
        }
        List<String> words = new ArrayList<>();
        for(List<Integer> list : patternMap.values()) {
            String first = arr[list.get(0)];
            if(words.contains(first)) {
                return false;
            }
            words.add(first);
            for(Integer index : list) {
                if(!arr[index].equals(first)) {
                    return false;
                }
            }
        }
        return true;
    }

    public boolean wordPattern1(String pattern, String str) {
        Map<String, Character> str2ch = new HashMap<String, Character>();
        Map<Character, String> ch2str = new HashMap<Character, String>();
        int m = str.length();
        int i = 0;
        for (int p = 0; p < pattern.length(); ++p) {
            char ch = pattern.charAt(p);
            if (i >= m) {
                return false;
            }
            int j = i;
            while (j < m && str.charAt(j) != ' ') {
                j++;
            }
            String tmp = str.substring(i, j);
            if (str2ch.containsKey(tmp) && str2ch.get(tmp) != ch) {
                return false;
            }
            if (ch2str.containsKey(ch) && !tmp.equals(ch2str.get(ch))) {
                return false;
            }
            str2ch.put(tmp, ch);
            ch2str.put(ch, tmp);
            i = j + 1;
        }
        return i >= m;
    }


    /**
     * 389. 找不同
     *
     * @param s
     * @param t
     * @return
     */
    public char findTheDifference(String s, String t) {
        Map<Character, Integer> map = new HashMap<>();
        for (int i = 0; i < s.length(); i++) {
            map.put(s.charAt(i), map.getOrDefault(s.charAt(i), 0) + 1);
        }
        for (int i = 0; i < t.length(); i++) {
            map.put(t.charAt(i), map.getOrDefault(t.charAt(i), 0) - 1);
        }
        char res = '0';
        for (Map.Entry<Character, Integer> entry : map.entrySet()) {
            if (entry.getValue() < 0) {
                res = entry.getKey();
                break;
            }
        }
        return res;
    }

    public char findTheDifference1(String s, String t) {
        int ret = 0;
        for (int i = 0; i < s.length(); i++) {
            ret ^= s.charAt(i);
        }
        for (int i = 0; i < t.length(); i++) {
            ret ^= t.charAt(i);
        }
        return (char) ret;
    }

    /**
     * 1005. K 次取反后最大化的数组和
     * @param A
     * @param K
     * @return
     */
    public int largestSumAfterKNegations(int[] A, int K) {
        PriorityQueue<Integer> minHeap = new PriorityQueue<>();
        int res = 0;
        for(int item : A) {
            minHeap.add(item);
            res += item;
        }
        while(K > 0) {
            int item = minHeap.poll();
            if(item != 0) {
                res -= 2*item;
                minHeap.add(0-item);
            } else if(item == 0) {
                break;
            }
            K--;
        }
        return res;
    }

    /**
     * 387. 字符串中的第一个唯一字符
     * @param s
     * @return
     */
    public int firstUniqChar(String s) {
        int result = Integer.MAX_VALUE;
        int[] res = new int[26];
        for(int i = 0; i < s.length(); i++) {
            if(res[s.charAt(i) - 'a'] == -1) {
                continue;
            } else if(res[s.charAt(i) - 'a'] != 0) {
                res[s.charAt(i) - 'a'] = -1;
            } else {
                res[s.charAt(i)- 'a'] = i + 1;
            }
        }
        for(Integer i : res) {
            if(i > 0) {
                if(result > i - 1) result = i-1;
            }
        }
        if (result != Integer.MAX_VALUE) {
            return result;
        } else {
            return -1;
        }
    }

    /**
     * 1201. 丑数 III
     * @param n
     * @param a
     * @param b
     * @param c
     * @return
     */
    public int nthUglyNumber(int n, int a, int b, int c) {
        int num = 0;
        for(int i = 1; i < Integer.MAX_VALUE; i++) {
            if(i % a == 0 || i % b == 0 || i % c == 0) {
                num++;
                if(num == n) {
                    return i;
                }
            }
        }
        return -1;
    }

    /**
     * 135. 分发糖果
     * @param ratings
     * @return
     */
    public int candy(int[] ratings) {
        List<CandyResult> list = new ArrayList<>();
        for(Integer grade : ratings) {
            if(list.size() == 0) {
                list.add(new CandyResult(grade, 1));
                continue;
            }
            CandyResult lastCandyRes = list.get(list.size() - 1);
            if(grade > lastCandyRes.grade) {
                list.add(new CandyResult(grade, lastCandyRes.candyNum + 1));
            } else {
                list.add(new CandyResult(grade, 1));
                if (grade < lastCandyRes.grade && lastCandyRes.candyNum == 1) {
                    for (int i = list.size() - 1; i > 0; i--) {
                        CandyResult candyResult = list.get(i);
                        CandyResult preCandyResult = list.get(i-1);
                        if(preCandyResult.grade > candyResult.grade && preCandyResult.candyNum <= candyResult.candyNum) {
                            preCandyResult.candyNum = candyResult.candyNum + 1;
                        } else {
                            break;
                        }
                    }
                }
            }
        }
        int num = 0;
        for(CandyResult candyResult : list) {
            num += candyResult.candyNum;
        }
        return num;
    }

    class CandyResult {
        public Integer grade;
        public Integer candyNum;
        public CandyResult(Integer grade, Integer candy) {
            this.grade = grade;
            this.candyNum = candy;
        }
    }

    public int candy1(int[] ratings) {
        int num = 0;
        int[] left = new int[ratings.length];
        for (int i = 0; i <= ratings.length - 1; i++) {
            if (i > 0 && ratings[i] > ratings[i-1]) {
                left[i] = left[i-1] + 1;
            } else {
                left[i] = 1;
            }
        }
        int right  = 0;
        for (int i = ratings.length - 1; i >= 0; i--) {
            if (i < ratings.length - 1 && ratings[i] > ratings[i+1]) {
                right++;
            } else {
                right = 1;
            }
            num += Math.max(left[i], right);
        }
        return num;
    }

    /**
     * 330. 按要求补齐数组
     * @param nums
     * @param n
     * @return
     */
    public int minPatches(int[] nums, int n) {
        for(int i = 0; i < nums.length; i++) {
//            nums[i] =
        }
        return 0;
    }

    /**
     * 947. 移除最多的同行或同列石头
     * @param stones
     * @return
     */
//    public int removeStones(int[][] stones) {
//        int groups = stones.length;
//        int[] parents = new int[stones.length];
//        Map<Integer, List<Integer>> map = new HashMap<>();
//        for(int i = 0; i < stones.length; i++) {
//            for(int j = 0; j < stones.length; j++) {
//                if(map.containsKey(i)) {
//                    List<Integer> list = map.get(i);
//                    list.add(j);
//                } else {
//                    List<Integer> list = new ArrayList<>();
//                    list.add(j);
//                    map.put(i, list);
//                }
//            }
//        }
//    }

//    public int findSet(map<int, int> &group, int id) {
//        if (group[id] == id) return id;
//        int setId = findSet(group, group[id]);
//        group[id] = setId;
//        return setId;
//    }
//
//    void unionSet(map<int, int> &group, int ida, int idb) {
//        if (ida > idb) return unionSet(group, idb, ida);
//        if (ida == idb) return ;
//        int seta = findSet(group, ida);
//        int setb = findSet(group, idb);
//        group[setb] = seta;
//    }
//
//    int removeStones(vector<vector<int>>& stones) {
//        //printf("\r\n");
//        map<int, int> rowGroup;             // row -> group id
//        map<int, vector<int>> rowPoints;    // row -> col list
//        map<int, vector<int>> colPoints;    // col -> row list
//        set<int> groupCount;
//        for (auto & stone : stones) {
//            int rowId = stone.front();
//            int colId = stone.back();
//            //printf("check point: (%d, %d)\r\n", rowId, colId);
//            if (rowGroup.count(rowId) < 1) { // row already exists, find col to connect
//                rowGroup[rowId] = rowId;
//            }
//            for (auto connectedRowId : colPoints[colId]) {
//                unionSet(rowGroup, rowId, connectedRowId);
//            }
//            rowPoints[rowId].push_back(colId);
//            colPoints[colId].push_back(rowId);
//            //printf("group[%d] = %d\r\n", rowId, findSet(rowGroup, rowId));
//        }
//
//        for (auto rgp : rowPoints) groupCount.insert(findSet(rowGroup, rgp.first));
//        /*
//        for (auto rid : rowPoints) {
//            printf("row id: %d, groupId: %d\r\n", rid.first, findSet(rowGroup, rid.first));
//        }
//        */
//        return stones.size() - groupCount.size();
//    }

    /**
     * 888. 公平的糖果棒交换
     * @param A
     * @param B
     * @return
     */
    public int[] fairCandySwap(int[] A, int[] B) {
        int[] res =  new int[2];
        int sumA = 0;
        int sumB = 0;
        Map<Integer, Integer> map= new HashMap<>();
        for(Integer item : A) {
            sumA += item;
            map.put(item, 0);
        }
        for(Integer item : B) {
            sumB += item;
        }
        int diff = (sumA -sumB)/2;
        for(Integer y : B) {
            int x = diff + y;
            if(map.containsKey(x)) {
                res[0] = x;
                res[1] = y;
                break;
            }
        }
        return res;
    }

    /**
     * 424. 替换后的最长重复字符
     * @param s
     * @param k
     * @return
     */
    public int characterReplacement(String s, int k) {
        return 0;
    }

    /**
     * 124. 二叉树中的最大路径和
     * @param root
     * @return
     */
    int length = Integer.MIN_VALUE;
//    public int maxPathSum(TreeNode root) {
//        oneSideMax(root);
//        return length;
//    }
//
//    private int oneSideMax(TreeNode root) {
//        if (root == null) {
//            return 0;
//        }
//        int left = Math.max(0, oneSideMax(root.left));
//        int right = Math.max(0, oneSideMax(root.right));
//        length = Math.max(length, left + right + root.val);
//        return Math.max(left, right) + root.val;
//    }

    /**
     * 509. 斐波那契数
     * 递归算法+备忘录/自顶向下
     * @param n
     * @return
     */
    Map<Integer, Integer> map = new HashMap<>();
    public int fib(int n) {
        if(n == 0) {
            return 0;
        }
        if (n == 1) {
            return 1;
        }
        if(!map.containsKey(n)) {
            map.put(n, map.getOrDefault(n-1, fib(n-1)) + map.getOrDefault(n-2, fib(n-2)));
        }
        return map.get(n);
    }



    /**
     * 509. 斐波那契数
     * 动态规划/自底向上
     * @param n
     * @return
     */
    public int fib1(int n) {
        if(n == 0) {
            return 0;
        }
        if (n == 1) {
            return 1;
        }
        int[] dp = new int[n];
        dp[1]=dp[2]=1;
        for(int i = 3; i <= n; i++) {
            dp[n] = dp[n-1] + dp[n-2];
        }
        return dp[n];
    }

    public int fib2(int n) {
        if (n == 2 || n == 1)
            return 1;
        int prev = 1, curr = 1;
        for (int i = 3; i <= n; i++) {
            int sum = prev + curr;
            prev = curr;
            curr = sum;
        }
        return curr;
    }

    /**
     * 322. 零钱兑换
     * @param coins
     * @param amount
     * @return
     */
    public int coinChange(int[] coins, int amount) {
        if(amount == 0) {
            return 0;
        }
        if(amount < 0) {
            return -1;
        }
        int min = Integer.MAX_VALUE;
        for(Integer coin : coins) {
            int res = coinChange(coins, amount - coin);
            if(res >= 0 && res < min) {
                min = res + 1;
            }
        }
        return (min == Integer.MAX_VALUE) ? -1 : min;
    }

    public int coinChange1(int[] coins, int amount) {
        return coinChange(coins, amount, new int[amount+1]);
    }
    private int coinChange(int[] coins, int rem, int[] count) {
        if (rem < 0) {
            return -1;
        }
        if (rem == 0) {
            return 0;
        }
        if (count[rem - 1] != 0) {
            return count[rem - 1];
        }
        int min = Integer.MAX_VALUE;
        for (int coin : coins) {
            int res = coinChange(coins, rem - coin, count);
            if (res >= 0 && res < min) {
                min = 1 + res;
            }
        }
        count[rem - 1] = (min == Integer.MAX_VALUE) ? -1 : min;
        return count[rem - 1];
    }

    public int coinChange2(int[] coins, int amount) {
        int[] dp = new int[amount+1];
        Arrays.fill(dp, amount+1);
        dp[0] = 0;
        for(int i = 0; i < dp.length; i++){
            for (int coin : coins) {
                if (i - coin < 0) continue;
                dp[i] = Math.min(1 + dp[i - coin], dp[i]);
            }
        }
        return (dp[amount] == amount + 1) ? -1 : dp[amount];
    }

    /**
     * 300. 最长递增子序列
     * @param nums
     * @return
     */
    public int lengthOfLIS(int[] nums) {
        int[] dp = new int[nums.length];
        dp[0] = 1;
        for(int i = 0; i < nums.length; i++) {
            for(int j = 0; j < i; j++) {
               if(nums[i] > nums[j]) {
                   dp[i] = Math.max(dp[j]+1, dp[i]);
               }
            }
        }
        int res = 0;
        for (int i = 0; i < dp.length; i++) {
            res = Math.max(res, dp[i]);
        }
        return res;
    }

//    private int lengthOfLIS(int[] nums, int value) {
//        if(nums.length == 1) return 1;
//        if(value > nums[nums.length - 1]) {
//            return lengthOfLIS(Arrays.copyOfRange(nums, 0, nums.length-1), nums[nums.length-1]) + 1;
//        } else {
//            return lengthOfLIS(Arrays.copyOfRange(nums, 0, nums.length-1), nums[nums.length-1]);
//        }
//    }
//    public int lengthOfLIS0(int[] nums) {
//        if(nums.length == 1) return 1;
//        return lengthOfLIS0(Arrays.copyOfRange(nums, 0, nums.length-1), nums[nums.length-1]);
//    }
//
//    private int lengthOfLIS0(int[] nums, int value) {
//        if(nums.length == 1) return 1;
//        if(value > nums[nums.length - 1]) {
//            return lengthOfLIS0(Arrays.copyOfRange(nums, 0, nums.length-1), nums[nums.length-1]) + 1;
//        } else {
//            return lengthOfLIS0(Arrays.copyOfRange(nums, 0, nums.length-1), nums[nums.length-1]);
//        }
//    }
//
//    int max = 0;
//    public int lengthOfLIS1(int[] nums) {
//        if(nums.length == 1) return 1;
//        lengthOfLIS1(Arrays.copyOfRange(nums, 0, nums.length-1), nums[nums.length-1]);
//        return max;
//    }
//    private int lengthOfLIS1(int[] nums, int value) {
//        if(nums.length == 1) return 1;
//        int subMax = lengthOfLIS1(Arrays.copyOfRange(nums, 0, nums.length-1), nums[nums.length-1]);
//        if(value > nums[nums.length - 1]) {
//            max = Math.max(subMax +1, max);
//        } else {
//            max = Math.max(subMax, max);
//        }
//        return max;
//    }

    /**
     * 14. 最长公共前缀
     * @param strs
     * @return
     */
    public String longestCommonPrefix(String[] strs) {
        if(strs.length == 0) {
            return "";
        }
        for(int i = 0; i < strs[0].length(); i++) {
            for(int j = 1; j < strs.length; j++) {
                if (i == strs[j].length() || strs[j].charAt(i) != strs[0].charAt(i)) {
                    return strs[0].substring(0, i);
                }
            }
        }
        return strs[0];
    }

    /**
     * 72. 编辑距离???
     * @param word1
     * @param word2
     * @return
     */
    public int minDistance(String word1, String word2) {
        int[][] dp = new int[word1.length()][word2.length()];
        Arrays.fill(dp, Math.max(word1.length(), word2.length()));
        for(int i = 1; i < word1.length(); i++) {
            for (int j = 1; j < word2.length(); j++) {
                if(word1.charAt(i) == word2.charAt(j)){
                    dp[i][j] = dp[i - 1][j - 1];
                } else {
                    dp[i][j] = Math.min(Math.min(dp[i][j-1] + 1, dp[i-1][j] + 1), dp[i-1][j-1] + 1);
                }
            }
        }
        return dp[word1.length()-1][word2.length()-1];
    }

    /**
     * 766. 托普利茨矩阵
     * @param matrix
     * @return
     */
    public boolean isToeplitzMatrix(int[][] matrix) {
        int row = matrix.length;
        int col = matrix[0].length;
        for(int i = 0; i < row - 1; i++) {
            for(int j = 0; j < col - 1; j++) {
                if(matrix[i][j] != matrix[i+1][j+1]) return false;
            }
        }
        return true;
    }

    /**
     * 832. 翻转图像
     * @param A
     * @return
     */
    public int[][] flipAndInvertImage(int[][] A) {
        int row = A.length;
        int col = A[0].length;
        for(int i = 0; i < row; i++) {
            for (int j = 0; j < col/2; j++) {
                    int tmp = A[i][j];
                    A[i][j] = A[i][col-1-j];
                    A[i][col-1-j] = tmp;
            }
        }
        for(int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
                if(A[i][j] == 0) {
                    A[i][j] = 1;
                } else {
                    A[i][j] = 0;
                }
            }
        }
        return A;
    }

    public int[][] flipAndInvertImage_1(int[][] A) {
        int row = A.length;
        for(int i = 0; i < row; i++) {
            int left = 0, right = row - 1;
            while(left < right) {
                if (A[i][left] == A[i][right]) {
                    //^(异或运算) ，针对二进制，相同的为0，不同的为1
                    A[i][left] ^= 1;
                    A[i][right] ^= 1;
                }
                left++;
                right--;
            }
            if (left == right) {
                A[i][left] ^= 1;
            }
        }
        return A;
    }

    /**
     * 867. 转置矩阵
     * @param matrix
     * @return
     */
    public int[][] transpose(int[][] matrix) {
        int row = matrix.length;
        int col = matrix[0].length;
        int[][] res = new int[col][row];
        for(int i = 0; i < row; i++) {
            for(int j = 0; j < col; j++) {
                res[j][i] = matrix[i][j];
            }
        }
        return res;
    }

    /**
     * 46. 全排列
     * @param nums
     * @return
     */
    List<List<Integer>> permuteRes = new ArrayList<>();
    public List<List<Integer>> permute(int[] nums) {
        backtrack(new ArrayList<>(), nums);
        return permuteRes;
    }
    private void backtrack(List<Integer> track, int[] nums) {
        if(track.size() == nums.length) {
            permuteRes.add(new ArrayList<>(track));
            return;
        }
        for(Integer num : nums){
            if(track.contains(num)) {
                continue;
            }
            track.add(num);
            backtrack(track, nums);
            track.remove(track.size() - 1);
        }
    }

    /**
     * 51. N 皇后
     * @param n
     * @return
     */
    List<List<String>> solveNQueensRes = new ArrayList<>();
    public List<List<String>> solveNQueens(int n) {
        char[][] board = new char[n][n];
        for (int i = 0; i < board.length; i++) {
            for (int j = 0; j < board[0].length; j++) {
                board[i][j] = '.';
            }
        }
        solveNQueensBackTrack(board, 0);
        return solveNQueensRes;
    }
    private void solveNQueensBackTrack(char[][] board, int row) {
        if(row == board.length) {
            List<String> res = new ArrayList<>();
            for (int i = 0; i < board.length; i++) {
                StringBuilder builder = new StringBuilder();
                for(int j = 0; j < board[0].length; j++) {
                    builder.append(board[i][j]);
                }
                res.add(builder.toString());
            }
            solveNQueensRes.add(res);
            return;
        }
        int col = board[0].length;
        for(int i = 0 ; i < col; i++) {
            if(!isValid(board, row, i))
                continue;
            board[row][i] = 'Q';
            solveNQueensBackTrack(board, row + 1);
            board[row][i] = '.';
        }
    }
    private boolean isValid(char[][] board, int rowIndex, int colIndex) {
        int row = board.length;
        // 检查列是否有皇后互相冲突
        for (int i = 0; i < row; i++) {
            if(board[i][colIndex] == 'Q') {
                return false;
            }
        }
        // 检查左上方是否有皇后互相冲突
        for(int i = rowIndex - 1, j = colIndex - 1; i >= 0 && j >= 0; i--,j--) {
            if(board[i][j] == 'Q') {
                return false;
            }
        }
        // 检查右上方是否有皇后互相冲突
        for(int i = rowIndex - 1, j = colIndex + 1; i >= 0 && j < row; i--,j++) {
            if(board[i][j] == 'Q') {
                return false;
            }
        }
        return true;
    }

    /**
     * 1178. 猜字谜
     * @param words
     * @param puzzles
     * @return
     */
    public List<Integer> findNumOfValidWords(String[] words, String[] puzzles) {
        Map<Integer, Integer> frequency = new HashMap<Integer, Integer>();
        for(String word : words) {
            int mask = 0;
            for(int i = 0; i < word.length(); i++) {
                char ch = word.charAt(i);
                mask |= (1 << (ch - 'a'));
            }
            if(Integer.bitCount(mask) <= 7) {
                frequency.put(mask, frequency.getOrDefault(mask, 0) + 1);
            }
        }
        List<Integer> ans = new ArrayList<Integer>();
        for (String puzzle : puzzles) {
            int total = 0;
            for(int choose = 0; choose < (1<<6); choose++) {
                int mask = 0;
                for(int i = 0; i < 6; i++) {
                    if((choose & (1 << i)) != 0) {
                        mask |= (1 << (puzzle.charAt(i + 1) - 'a'));
                    }
                }
                mask |= (1 << (puzzle.charAt(0) - 'a'));
                if (frequency.containsKey(mask)) {
                    total += frequency.get(mask);
                }
            }
            ans.add(total);
        }
        return ans;
    }

    /**
     * 395. 至少有K个重复字符的最长子串
     * @param s
     * @param k
     * @return
     */
    public int longestSubstring(String s, int k) {
        return 0;
    }

    /**
     * 896. 单调数列
     * @param A
     * @return
     */
    public boolean isMonotonic(int[] A) {
        if(A.length == 1) {
            return true;
        }
        String increaseFlag = "";
        for(int i = 1; i < A.length; i++) {
            if(A[i] == A[i-1]) {
                continue;
            }
            if(increaseFlag.equals("")) {
                increaseFlag = A[i] > A[i-1] ? "1" : "0";
            }
            if(increaseFlag.equals("1") && A[i] < A[i-1]) {
                return false;
            }
            if(increaseFlag.equals("0") && A[i] > A[i-1]) {
                return false;
            }
        }
        return true;
    }


    public static void main(String[] args) {
        Test test = new Test();

//        System.out.println(test.sortString("aabbbcccc"));
//        System.out.println(test.sortString("aaaabbbbcccc"));
//        System.out.println(test.sortString("leetcode"));
//        System.out.println(test.sortString("rat"));

//        char[][] board ={
//                {'a', 'b', 'c', 'd', 'e'},
//                {'f', 'g', 'h', 'i', 'j'},
//                {'k', 'l', 'm', 'n', 'o'},
//                {'p', 'q', 'r', 's', 't'},
//                {'u', 'v', 'w', 'x', 'y'},
//                {'z'}};
//        System.out.println(board[0][0]);
//        System.out.println(test.alphabetBoardPath("zdz"));
//        System.out.println(test.alphabetBoardPath("code"));
//        test.isTransformable("84532", "34852");
        int[][] arr = {{0, 1, 0, 0}, {1, 1, 1, 0}, {0, 1, 0, 0}, {1, 1, 0, 0}};
//        System.out.println(test.islandPerimeter(arr));
//        System.out.println(test.spiralMatrixIII(5, 6, 1, 4));
//        System.out.println(test.isPossible1(new int[]{1, 2, 3, 3, 4, 4, 5, 5}));
//        System.out.println(test.lengthOfLongestSubstring("cdd"));
//        System.out.println(test.lengthOfLongestSubstring("abcabcbb"));
//        System.out.println(test.lengthOfLongestSubstring("pwwkew"));
//        System.out.println(test.lengthOfLongestSubstring(" "));
//        System.out.println(test.lengthOfLongestSubstring("dedv"));
//        System.out.println(test.lengthOfLongestSubstring("abba"));
//        System.out.println(test.lengthOfLongestSubstring("abcb"));
//        System.out.println(test.lengthOfLongestSubstring("tmmzuxt"));
//        System.out.println(test.groupAnagrams(new String[]{"eat", "tea", "tan", "ate", "nat", "bat"}));
//        System.out.println(test.monotoneIncreasingDigits(1234));
//        System.out.println(test.monotoneIncreasingDigits(332));
//        System.out.println(test.monotoneIncreasingDigits(3322));
//        System.out.println(test.monotoneIncreasingDigits(101));
//        System.out.println(test.monotoneIncreasingDigits(110));
//        System.out.println(test.monotoneIncreasingDigits(120));
//        System.out.println(test.wordPattern1("abba", "dog dog dog dog"));
//        System.out.println(test.findTheDifference1("abbc", "cdbba"));
//        System.out.println(test.largestSumAfterKNegations(new int[]{-2, 9, 9, 8, 4}, 5));
//        int a = 1;
//        int b = 2;
//        int c = 3;
//        a = b = c;
//        System.out.println(a);
//        System.out.println(b);
//        System.out.println(c);
//        System.out.println(test.nthUglyNumber(1000000000, 2, 217983653, 336916467));
//        System.out.println(test.candy1(new int[]{1,0,2}));
//        System.out.println(test.coinChange(new int[]{1,2,5}, 11));
//        System.out.println(test.lengthOfLIS(new int[]{0,1,0,3,2,3}));
//        System.out.println(test.longestCommonPrefix(new String[]{"ab", "a"}));

        int[][] A = new int[][]{
                {1, 1, 0, 0},
                {1, 0, 0, 1},
                {0, 1, 1, 1},
                {1, 0, 1, 0}};
//        System.out.println(test.flipAndInvertImage(A));
//        System.out.println(test.permute(new int[]{1, 2, 3}));
//        System.out.println(test.solveNQueens(4));
//        Integer test1 = (Integer) null;
//        Double test2 = (Double) null;
//        Boolean test3 = (Boolean) null;
//        System.out.println(test1.getClass());
////        System.out.println(test1.intValue());
////        System.out.println(test1==0);
//        System.out.println(test2);
//        System.out.println(test3);

        Boolean b1 = false;
        Boolean b2 = false;
        Boolean b3 = true;
        Boolean b4 = true;
        System.out.println(b1 == b2); //true
        System.out.println(b3 == b4); //true

        Integer a = 1;
        Integer b = 2;
        Integer c = 3;
        Integer d = 3;
        Integer e = 321;
        Integer f = 321;
        Long g = 3L;
        Long h = 2L;
        System.out.println(c == d); //true
        System.out.println(e == f); //false
        System.out.println(c == (a + b)); //true
        System.out.println(c.equals(a + b)); //true
        System.out.println(g == (a + b)); //true
        System.out.println(g.equals(a + b)); //false
        System.out.println(g.equals(a + h)); //true
        System.out.println("***************1");

        Integer a_1 = 444;
        int b_1 = 444;
        System.out.println(a_1==b_1); //true
        System.out.println(a_1.equals(b_1)); //true
        System.out.println("***************2");

        Integer i1 = new Integer(127);
        Integer i2 = new Integer(127);
        System.out.println(i1 == i2); //false
        System.out.println(i1.equals(i2));//true

        Integer i3 = new Integer(128);
        Integer i4 = new Integer(128);
        System.out.println(i3 == i4);  //false
        System.out.println(i3.equals(i4));  //true
        System.out.println("***************3");

        Integer i5 = 128;
        Integer i6 = 128;
        System.out.println(i5 == i6);  //false
        System.out.println(i5.equals(i6));  //true

        Integer i7 = 127;
        Integer i8 = 127;
        System.out.println(i7 == i8);  //true
        System.out.println(i7.equals(i8));  //true
    }
}


