package com.aidar;

import java.util.HashMap;
import java.util.Map;

public class DoublePointer {
    /**
     * 76. 最小覆盖子串
     *
     * @param s
     * @param t
     * @return
     */
    public String minWindow(String s, String t) {
        Map<Character, Integer> needs = new HashMap<>();
        Map<Character, Integer> windows = new HashMap<>();
        for (char c : t.toCharArray()) {
            needs.put(c, needs.getOrDefault(c, 0) + 1);
        }
        int left = 0, right = 0, start = 0;
        int sLen = s.length();
        int minLen = Integer.MAX_VALUE;
        while (right < sLen) {
            char rightChar = s.charAt(right);
            if (needs.containsKey(rightChar)) {
                windows.put(rightChar, windows.getOrDefault(rightChar, 0) + 1);
            }
            boolean equalFlag = true;
            for (char key : needs.keySet()) {
                if (needs.get(key) > windows.getOrDefault(key, 0)) {
                    equalFlag = false;
                    break;
                }
            }

            while (left <= right && equalFlag && right - left +1>= t.length()) {
                char leftChar = s.charAt(left);
                for (char key : needs.keySet()) {
                    if (needs.get(key) > windows.getOrDefault(key, 0)) {
                        equalFlag = false;
                        break;
                    }
                }
                if(equalFlag && minLen > right - left + 1) {
                    start = left;
                    minLen = right - left + 1;
                }
                if (windows.containsKey(leftChar)) {
                    windows.put(leftChar, windows.get(leftChar) - 1);
                }
                left++;
            }
            right++;
        }
        return minLen == Integer.MAX_VALUE ? "":s.substring(start, start + minLen);
    }

    public String minWindow1(String s, String t) {
        Map<Character, Integer> needs = new HashMap<>();
        Map<Character, Integer> windows = new HashMap<>();
        for (char c : t.toCharArray()) {
            needs.put(c, needs.getOrDefault(c, 0) + 1);
        }
        int left = 0, right = 0, start = 0;
        int sLen = s.length();
        int minLen = Integer.MAX_VALUE;
        int match = 0;
        while (right < sLen) {
            char rightChar = s.charAt(right);
            if (needs.containsKey(rightChar)) {
                windows.put(rightChar, windows.getOrDefault(rightChar, 0) + 1);
                if(needs.get(rightChar) == windows.get(rightChar)) {
                    match++;
                }
            }

            while (match == needs.size()) {
                char leftChar = s.charAt(left);
                if(minLen > right - left) {
                    start = left;
                    minLen = right - left;
                }
                if (needs.containsKey(leftChar)) {
                    windows.put(leftChar, windows.get(leftChar) - 1);
                    if(windows.get(leftChar) < needs.get(leftChar)) {
                        match--;
                    }
                }
                left++;
            }
            right++;
        }
        return minLen == Integer.MAX_VALUE ? "":s.substring(start, start + minLen + 1);
    }

    /**
     * 1052. 爱生气的书店老板
     * @param customers
     * @param grumpy
     * @param X
     * @return
     */
    public int maxSatisfied(int[] customers, int[] grumpy, int X) {
         int convertToSatisfiedNum = 0;
         int start = 0;
         for(int i = 0; i < grumpy.length; i++) {
            if(grumpy[i] == 1) {
                int tmp = 0;
                for(int j = i; j < Math.min(i + X, grumpy.length); j++) {
                    if(grumpy[j] == 1) {
                        tmp += customers[j];
                    }
                }
                if(tmp > convertToSatisfiedNum) {
                    convertToSatisfiedNum = tmp;
                    start = i;
                }
            }
         }
         int num = 0;
         for(int i = 0; i < customers.length; i++) {
             if(grumpy[i] == 0 || (i >= start && i < start+X)) {
                 num += customers[i];
             }
         }
         return num;
    }


    public static void main(String[] args) {
        DoublePointer dp = new DoublePointer();
//        System.out.println(dp.minWindow1("ADOBECODEBANC", "ABC"));
//        System.out.println(dp.minWindow1("abc", "ab"));
//        System.out.println(dp.minWindow1("cabwefgewcwaefgcf", "cae"));
        System.out.println(dp.maxSatisfied(new int[]{1,0,1,2,1,1,7,5}, new int[]{0,1,0,1,0,1,0,1}, 3));
        System.out.println(dp.maxSatisfied(new int[]{6,10,2,1,7,9}, new int[]{1,0,0,0,0,1}, 3));
    }
}
