package com.aidar.string;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Test {

    /**
     * 131. 分割回文串
     *
     * @param s
     * @return
     */
    List<List<String>> partitionRes = new ArrayList<>();
    List<String> track = new ArrayList<>();
    boolean[][] dp;

    public List<List<String>> partition(String s) {
        int len = s.length();
        dp = new boolean[len][len];
        for (int i = 0; i < len; i++) {
            Arrays.fill(dp[i], true);
        }
        for (int i = len - 1; i >= 0; i--) {
            for (int j = i + 1; j < len; j++) {
                dp[i][j] = dp[i + 1][j - 1] && (s.charAt(i) == s.charAt(j));
            }
        }
        backtrack(s, 0);
        return partitionRes;
    }

    private void backtrack(String s, int i) {
        if (i == s.length()) {
            partitionRes.add(new ArrayList<String>(track));
            return;
        }
        for (int j = i; j < s.length(); j++) {
            if (dp[i][j]) {
                track.add(s.substring(i, j + 1));
                backtrack(s, j + 1);
                track.remove(track.size() - 1);
            }
        }
    }


    /**
     * 132. 分割回文串 II
     *
     * @param s
     * @return
     */
    public int minCut(String s) {
        int len = s.length();
        boolean[][] dp = new boolean[len][len];
        for (int i = 0; i < len; i++) {
            Arrays.fill(dp[i], true);
        }
        for (int i = len - 1; i >= 0; i--) {
            for (int j = i + 1; j < len; j++) {
                dp[i][j] = dp[i + 1][j - 1] && (s.charAt(i) == s.charAt(j));
            }
        }
        int[] f = new int[len];
        Arrays.fill(f, Integer.MAX_VALUE);
        for (int i = 0; i < len; i++) {
            if (dp[0][i]) {
                f[i] = 0;
            } else {
                for (int j = 0; j < i; j++) {
                    if (dp[j + 1][i]) {
                        f[i] = Math.min(f[i], f[j] + 1);
                    }
                }
            }
        }
        return f[len - 1];
    }

    /**
     * 1047. 删除字符串中的所有相邻重复项
     *
     * @param S
     * @return
     */
    public String removeDuplicates(String S) {
        Stack<Character> stack = new Stack<>();
        for (int i = 0; i < S.length(); i++) {
            if (!stack.isEmpty()) {
                if (stack.peek() == S.charAt(i)) {
                    stack.pop();
                    continue;
                }
            }
            stack.add(S.charAt(i));
        }
        StringBuilder builder = new StringBuilder();
        while (!stack.isEmpty()) {
            builder.insert(0, stack.pop());
        }
        return builder.toString();
    }


    public String removeDuplicates_official(String S) {
        StringBuffer stack = new StringBuffer();
        int top = -1;
        for (int i = 0; i < S.length(); ++i) {
            char ch = S.charAt(i);
            if (top >= 0 && stack.charAt(top) == ch) {
                stack.deleteCharAt(top);
                --top;
            } else {
                stack.append(ch);
                ++top;
            }
        }
        return stack.toString();
    }

    /**
     * 224. 基本计算器
     *
     * @param s
     * @return
     */
    public int calculate(String s) {
        Stack<Integer> ops = new Stack<>();
        ops.push(1);
        int sign = 1;
        int res = 0;
        int i = 0;
        while (i < s.length()) {
            if (s.charAt(i) == '+') {
                sign = ops.peek();
                i++;
            } else if (s.charAt(i) == '-') {
                sign = -ops.peek();
                i++;
            } else if (s.charAt(i) == ' ') {
                i++;
            } else if (s.charAt(i) == '(') {
                ops.push(sign);
                i++;
            } else if (s.charAt(i) == ')') {
                ops.pop();
                i++;
            } else {
                long num = 0;
                while (i < s.length() && Character.isDigit(s.charAt(i))) {
                    num = num * 10 + s.charAt(i) - '0';
                    i++;
                }
                res += sign * num;
            }
        }
        return res;
    }

    /**
     * 227. 基本计算器 II
     *
     * @param s
     * @return
     */
    public int calculate_2(String s) {
        Deque<Integer> stack = new LinkedList<Integer>();
        char preSign = '+';
        int num = 0;
        int n = s.length();
        for (int i = 0; i < n; ++i) {
            if (Character.isDigit(s.charAt(i))) {
                num = num * 10 + s.charAt(i) - '0';
            }
            if (!Character.isDigit(s.charAt(i)) && s.charAt(i) != ' ' || i == n - 1) {
                switch (preSign) {
                    case '+':
                        stack.push(num);
                        break;
                    case '-':
                        stack.push(-num);
                        break;
                    case '*':
                        stack.push(stack.pop() * num);
                        break;
                    default:
                        stack.push(stack.pop() / num);
                }
                preSign = s.charAt(i);
                num = 0;
            }
        }
        int ans = 0;
        while (!stack.isEmpty()) {
            ans += stack.pop();
        }
        return ans;
    }

    /**
     * 6. Z 字形变换
     * @param s
     * @param numRows
     * @return
     */
    public String convert(String s, int numRows) {
//        if(s == null) {
//            return s;
//        }
//        char[][] dp = new char[numRows][s.length()];
//        int count = 0;
//        int i = 0, j = 0;
//        while (count < s.length()) {
//            if(i == 0) {
//                while (i < numRows && count < s.length()) {
//                    dp[i++][j] = s.charAt(count);
//                    count++;
//                }
//            }
//            if( i == numRows) {
//                i = numRows -2;
//                j++;
//                while (i > 0 && count < s.length()) {
//                    dp[i--][j++] = s.charAt(count);
//                    count++;
//                }
//            }
//        }
//        count = 0;
//        StringBuilder sb = new StringBuilder();
//        while (count < s.length()) {
//            for(int k = 0; k < numRows; k++) {
//                for (int l = 0; l < s.length(); l++) {
//                    if(dp[k][l] != 0) {
//                        sb.append(String.valueOf(dp[k][l]));
//                    }
//                    count++;
//                }
//            }
//        }
//        return sb.toString();
        return "";
    }

//    private enum OperatorEnum {
//        Add('+'),
//        Subtract('-'),
//        LeftBracket('('),
//        RightBracket(')'),
//        Space(' ');
//        private static final Map<Character, OperatorEnum> MAP = new HashMap<>();
//
//        static {
//            for (OperatorEnum operator : values()) {
//                MAP.put(operator.operator, operator);
//            }
//        }
//
//        private char operator;
//        private OperatorEnum(char operator) {
//            this.operator = operator;
//        }
//        public static OperatorEnum valueOfName(char name) {
//            return MAP.get(name);
//        }
//        private char getOperator() {
//            return operator;
//        }
//    }

    /**
     * 150. 逆波兰表达式求值
     * @param tokens
     * @return
     */
    public int evalRPN(String[] tokens) {
        Stack<Integer> stack = new Stack<>();
        for(String token :  tokens) {
            if(token.equals("+")) {
                int num2 = stack.pop();
                int num1 = stack.pop();
                stack.add(num1 + num2);
            } else if(token.equals("-")) {
                int num2 = stack.pop();
                int num1 = stack.pop();
                stack.add(num1 - num2);
            } else if(token.equals("*")) {
                int num2 = stack.pop();
                int num1 = stack.pop();
                stack.add(num1 * num2);
            } else if(token.equals("/")) {
                int num2 = stack.pop();
                int num1 = stack.pop();
                stack.add(num1 / num2);
            } else {
                stack.add(Integer.valueOf(token));
            }
        }
        return stack.pop();
    }


    public String convertString(String s) {
//        StringBuilder sb = new StringBuilder();
//        for(int i = s.length() - 1; i >=0 ; i--) {
//            sb.append(s.charAt(i));
//        }
//        return sb.toString();
        StringBuilder res = new StringBuilder(s);
        return res.reverse().toString();
    }


    public String deleteLeastChar(String s) {
        int[] arr = new int[26];
        Map<Character, List<Integer>> map = new HashMap<>();
        for(int i = 0; i < s.length(); i++) {
            arr[s.charAt(i) - 97] += 1;
            List<Integer> list = map.getOrDefault(s.charAt(i), new ArrayList<>());
            list.add(i);
            map.put(s.charAt(i), list);
        }
        int finalMin = Arrays.stream(arr).filter(x -> x != 0).min().getAsInt();
        List<Integer> filterMapValue = map.entrySet().stream().filter(x -> arr[x.getKey()-97] == finalMin)
                .map(entry -> entry.getValue())
                .reduce(new ArrayList<>(), (acc, v) -> {
                    acc.addAll(v);
                    return acc;
                });
        StringBuilder sb = new StringBuilder();
        for(int i = 0; i < s.length(); i++) {
            if(!filterMapValue.contains(i)) {
                sb.append(s.charAt(i));
            }
        }
        return sb.toString();
//        List<Character> filterMapValue = map.entrySet().stream().filter(x -> arr[x.getKey()-97] == finalMin)
//        .map(entry -> entry.getKey())
//        .collect(Collectors.toList());
//        char[] list = {'a','c','e'};
//        Stream<Character> charStream = new String(list).chars().mapToObj(i->(char)i);
//        Stream.of(s.chars()).filter(x -> filterMapValue.contains((char)x)).forEach(System.out::println);
//        Stream.of(s.chars()).forEach(System.out::println);
//        Stream.of(new Character[]{'a', 'b', 'c'}).forEach(System.out::println);
//        Stream.of(s.chars().mapToObj(i->(char)i)).filter(x -> !filterMapValue.contains(x)).forEach(System.out::println);
//        String sb = Stream.of(new Character[]{'a', 'b', 'c'}).filter(x -> !filterMapValue.contains(x)).map(x -> String.valueOf(x)).collect(Collectors.joining());
//        return sb;

//        filterMapValue.sort(new Comparator<Integer>() {
//            @Override
//            public int compare(Integer o1, Integer o2) {
//                return o1 - o2;
//            }
//        });
    }

    public String deleteLeastChar_1(String s) {
        char[] arr = new char[26];
        int min = Integer.MAX_VALUE;
        Map<Character, List<Integer>> map = new HashMap<>();
        for(int i = 0; i < s.length(); i++) {
            arr[s.charAt(i) - 97] += 1;
            if(arr[s.charAt(i) - 97] < min) {
                min = arr[s.charAt(i) - 97];
            }
            List<Integer> list = map.getOrDefault(s.charAt(i), new ArrayList<>());
            list.add(i);
            map.put(s.charAt(i), list);
        }
        int finalMin = min;
        List<Integer> filterMapValue = map.entrySet().stream()
                .filter(x -> arr[x.getKey()-97] == finalMin)
                .map(x -> x.getValue())
                .reduce(new ArrayList<>(), (acc, v)-> {
                    acc.addAll(v);
                    return acc;
                });
        StringBuilder sb = new StringBuilder();
        for(int i = 0; i < s.length(); i++) {
            if(!filterMapValue.contains(i)) {
                sb.append(s.charAt(i));
            }
        }
        return sb.toString();
    }

    /**
     * 1143. 最长公共子序列
     * @param text1
     * @param text2
     * @return
     */
    public int longestCommonSubsequence(String text1, String text2) {
        return 0;
    }

    /**
     * 28. 实现 strStr()
     * @param haystack
     * @param needle
     * @return
     */
    public int strStr(String haystack, String needle) {
        return haystack.indexOf(needle);
    }

    /**
     * 91. 解码方法
     * @param s
     * @return
     */
    public int numDecodings(String s) {
        if(s == null || (s.length() >=1 && s.charAt(0) == '0')) {
            return 0;
        }
        if(s.length() == 1 && !s.equals("0")) {
            return 1;
        }
        char pre = s.charAt(0);
        char now = ' ';
        int[] dp = new int[s.length()];
        dp[0] = 1;
        for(int i = 1; i < s.length(); i++) {
            now = s.charAt(i);
            if(pre == '0' && now != '0') {
                dp[i] = dp[i-1];
            }
            if(pre == '0' && now == '0') {
                return 0;
            }
            if(pre != '0' && now == '0') {
                if(pre == '1' || pre == '2') {
                    dp[i] = i >= 2 ? dp[i-2] : dp[0];
                } else {
                    return 0;
                }
            }
            if(pre != '0' && now != '0') {
                int nowInt = Integer.valueOf(now + "");
                if(pre == '1' || (pre == '2' && nowInt >0 && nowInt < 7)) {
                    int num = i >= 2 ? dp[i-2] : 1;
                    dp[i] = dp[i-1] + num;
                } else {
                    dp[i] = dp[i-1];
                }
            }
            pre = now;
        }
        return dp[s.length() - 1];
    }

    public int numDecodings_official_1(String s) {
        int len = s.length();
        int[] dp = new int[len+1];
        dp[0] = 1;
        for(int i = 1; i <=len; i++) {
            if(s.charAt(i-1) != '0') {
                dp[i] += dp[i-1];
            }
            if(i > 1 && s.charAt(i-2) != '0' && ((s.charAt(i - 2) - '0') * 10 + (s.charAt(i - 1) - '0') <= 26)) {
                dp[i] += dp[i-2];
            }
        }
        return dp[len];
    }

    public int numDecodings_official_2(String s) {
        int len = s.length();
        int a = 0, b = 1, c = 0;
        for(int i = 1; i <=len; i++) {
            c = 0;
            if(s.charAt(i-1) != '0') {
                c += b;
            }
            if(i > 1 && s.charAt(i-2) != '0' && ((s.charAt(i - 2) - '0') * 10 + (s.charAt(i - 1) - '0') <= 26)) {
                c += a;
            }
            a = b;
            b = c;
        }
        return c;
    }

    /**
     * 12. 整数转罗马数字
     * @param num
     * @return
     */
    public String intToRoman(int num) {
        return "";
    }


    public static void main(String[] args) {
        Test test = new Test();
//        System.out.println(test.calculate("1+1+2"));
//        System.out.println(test.convert("PAYPALISHIRING", 3));
//        System.out.println(test.evalRPN(new String[]{"10","6","9","3","+","-11","*","/","*","17","+","5","+"}));
//        System.out.println(test.deleteLeastChar("assssa"));
//        System.out.println(test.numDecodings("10"));
//        System.out.println(test.numDecodings("27"));
//        System.out.println(test.numDecodings("2101"));
//        System.out.println(test.numDecodings("1123"));
//        System.out.println(test.numDecodings_official("10"));
//        "aaa".indexOf("ab");
//        "aaa".indexOf("ab");
    }
}
