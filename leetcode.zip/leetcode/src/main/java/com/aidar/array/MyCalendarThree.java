package com.aidar.array;

import java.util.TreeMap;

/**
 * 732. 我的日程安排表 III
 */
public class MyCalendarThree {
    TreeMap<Integer, Integer> delta;
    public MyCalendarThree() {
        delta = new TreeMap<>();
    }

    public int book(int start, int end) {
        delta.put(start, delta.getOrDefault(start, 0) + 1);
        delta.put(end, delta.getOrDefault(end, 0) - 1);

        int active = 0, ans = 0;
        for(int d : delta.values()) {
            active += d;
            if(active > ans) {
                ans = active;
            }
        }
        return ans;
    }

    public static void main(String[] args) {
        MyCalendarThree obj = new MyCalendarThree();
        obj.book(10,20);
        obj.book(10,40);
        obj.book(5,15);
    }
}
