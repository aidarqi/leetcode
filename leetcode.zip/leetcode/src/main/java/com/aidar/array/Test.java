package com.aidar.array;

import java.awt.desktop.PreferencesEvent;
import java.sql.ClientInfoStatus;
import java.util.*;
import java.util.stream.Collectors;

public class Test {


    /**
     * 338. 比特位计数
     * 时间复杂度：O(k \times \textit{num})O(k×num)
     * @param num
     * @return
     */
    public int[] countBits(int num) {
        int[] res = new int[num+1];
        for(int i = 1; i <= num; i++) {
//            String item = Integer.toBinaryString(i);
            int count = 0;
//            for(int j = 0; j < item.length(); j++) {
//                count += Integer.valueOf(item.substring(j,j+1)) & 1;
//            }
            int item = i;
            while (item > 0) {
                item = item&(item-1);
                count++;
            }
            res[i] = count;
        }
        return res;
    }

    public int[] countBits1(int num) {
        int[] res = new int[num+1];
        int highBit = 0;
        for(int i = 1; i <= num; i++) {
            if((i & (i - 1)) == 0) {
                highBit = i;
            }
            res[i] = res[i - highBit] + 1;
        }
        return res;
    }

    /**
     * 354. 俄罗斯套娃信封问题
     * @param envelopes
     * @return
     */
    public int maxEnvelopes(int[][] envelopes) {
        if (envelopes.length == 0) {
            return 0;
        }
        int len = envelopes.length;
        Arrays.sort(envelopes, new Comparator<int[]>() {
            @Override
            public int compare(int[] o1, int[] o2) {
                if(o1[0] != o2[0]) {
                    return o1[0] - o2[0];
                } else {
                    return o2[1] - o1[1];
                }
            }
        });
        int[] dp = new int[len];
        Arrays.fill(dp, 1);
        int max = 1;
        for(int i = 1; i < len; i++) {
            for(int j = 0; j < i; j++) {
                if(envelopes[j][1] < envelopes[i][1]) {
                    dp[i] = Math.max(dp[j]+1, dp[i]);
                }
            }
            max = Math.max(max, dp[i]);
        }
        return max;
    }

    /**
     * 503. 下一个更大元素 II
     * @param nums
     * @return
     */
    public int[] nextGreaterElements(int[] nums) {
        int n = nums.length;
        int[] ret = new int[n];
        Arrays.fill(ret, -1);
        Deque<Integer> stack = new LinkedList<Integer>();
        for (int i = 0; i < n * 2 - 1; i++) {
            while (!stack.isEmpty() && nums[stack.peek()] < nums[i % n]) {
                ret[stack.pop()] = nums[i % n];
            }
            stack.push(i % n);
        }
        return ret;
    }

    /**
     * 54. 螺旋矩阵
     * @param matrix
     * @return
     */
//    public List<Integer> spiralOrder(int[][] matrix) {
//    }

    /**
     * 59. 螺旋矩阵 II
     * @param n
     * @return
     */
    public int[][] generateMatrix(int n) {
        int[][] matrix = new int[n][n];
        int left = 0, top = 0, right = n - 1, bottom = n - 1;
        int count = 1;
        while (count <= n*n) {
            for(int col = left; col <= right; col++) {
                matrix[top][col] = count;
                count++;
            }
            for(int row = top + 1; row <= bottom; row++) {
                matrix[row][right] = count;
                count++;
            }
            if(left < right && top < bottom) {
                for(int col = right - 1; col > left; col--) {
                    matrix[bottom][col] =  count;
                    count++;
                }
                for(int row = bottom; row > top; row --) {
                    matrix[row][left] = count;
                    count++;
                }
            }
            left++;
            right--;
            top++;
            bottom--;
        }
        return matrix;
    }

    /**
     * 115. 不同的子序列
     * @param s
     * @param t
     * @return
     */
    public int numDistinct(String s, String t) {
        int[][] dp = new int[s.length()+1][t.length()+1];
        if(s.length() < t.length()) {
            return 0;
        }
        for(int i = 0; i <= s.length(); i++) {
            dp[i][t.length()] = 1;
        }
        for(int i = s.length() - 1 ; i >= 0 ; i--) {
            for(int j = t.length() - 1; j >= 0 ; j--) {
                if(s.charAt(i) == t.charAt(j)) {
                    dp[i][j] = dp[i+1][j+1] + dp[i+1][j];
                } else {
                    dp[i][j] = dp[i+1][j];
                }
            }
        }
        return dp[0][0];
    }

    /**
     * 456. 132模式
     * @param nums
     * @return
     */
    public boolean find132pattern(int[] nums) {
        int left = 0;
        int right = nums.length - 1;

        while (left < right && nums[left] >= nums[right]) {
            left++;
        }

        while (left < right) {
            if(nums[left] >= nums[right]) {
                return true;
            }
            left++;
        }
        return false;
    }

    public boolean find132pattern_official_1(int[] nums) {
        int n = nums.length;
        if (n < 3) {
            return false;
        }

        // 左侧最小值
        int leftMin = nums[0];
        // 右侧所有元素
        TreeMap<Integer, Integer> rightAll = new TreeMap<Integer, Integer>();

        for (int k = 2; k < n; ++k) {
            rightAll.put(nums[k], rightAll.getOrDefault(nums[k], 0) + 1);
        }

        for (int j = 1; j < n - 1; ++j) {
            if (leftMin < nums[j]) {
                Integer next = rightAll.ceilingKey(leftMin + 1);
                if (next != null && next < nums[j]) {
                    return true;
                }
            }
            leftMin = Math.min(leftMin, nums[j]);
            //移除掉树中作为'3'的元素
            rightAll.put(nums[j + 1], rightAll.get(nums[j + 1]) - 1);
            if (rightAll.get(nums[j + 1]) == 0) {
                rightAll.remove(nums[j + 1]);
            }
        }

        return false;
    }


    /**
     * inter
     * @param arr
     * @return
     */
    public Integer[] sortArr(Integer[] arr) {
        Arrays.sort(arr, new Comparator<>() {
            @Override
            public int compare(Integer o1, Integer o2) {
                if(o1 < 0 && o2 < 0) {
                    return Math.abs(o1) - Math.abs(o2);
                } else {
                    return o2 - o1;
                }
            }
        });
        return arr;
    }

    public String stoneGameIII(int[] stoneValue) {
        int len = stoneValue.length;
        boolean AliceeFlag = true;
        int AliceScore = 0;
        int BobScore = 0;
        for(int i = 0; i < len;) {
            int[] sum = new int[3];
            Arrays.fill(sum, stoneValue[i]);
            int max = stoneValue[i];
            int maxIndex = i;
            for(int j = 1; j < 3 && i+j < len; j++) {
                sum[j] = sum[j-1] + stoneValue[i+j];
                if(sum[j] > max) {
                    max = sum[j];
                    maxIndex = j+i;
                }
            }
            if(AliceeFlag) {
                AliceScore += max;
                AliceeFlag = false;
            } else {
                BobScore += max;
                AliceeFlag = true;
            }
            i = maxIndex+1;
        }
        if(AliceScore > BobScore) {
            return "Alice";
        } else if(AliceScore < BobScore) {
            return "Bob";
        } else {
            return "tie";
        }
    }

    /**
     * 74. 搜索二维矩阵
     * @param matrix
     * @param target
     * @return
     */
    public boolean searchMatrix(int[][] matrix, int target) {
        int rowIndex = binarySearchFirstColumn(matrix, target);
        if (rowIndex < 0) {
            return false;
        }
        return binarySearchRow(matrix[rowIndex], target);
    }

    private int binarySearchFirstColumn(int[][] matrix, int target) {
        int top = -1, bottom = matrix.length - 1;
        while (top < bottom) {
            int mid = (bottom - top + 1)/2 + top;
            if(matrix[mid][0] <= target) {
                top = mid;
            } else {
                bottom = mid - 1;
            }
        }
        return top;
    }

    private boolean binarySearchRow(int[] row, int target) {
        int left = 0, right = row.length - 1;
        while(left <= right) {
            int mid = (right - left)/2 + left;
            if(row[mid] == target) {
                return true;
            } else if(row[mid] < target) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return false;
    }

    /**
     * 90. 子集 II
     * @param nums
     * @return
     */
    public List<List<Integer>> subsetsWithDup(int[] nums) {
        List<List<Integer>> res = new ArrayList<>();
        List<Integer> list = new ArrayList<>();
        int len = nums.length;
        Arrays.sort(nums);
        for(int mask = 0; mask < (1 << len); mask++){
            list.clear();
            boolean flag = true;
            for(int i = 0; i < len; i++) {
                if((mask & (1 << i)) != 0) {
                    if (i > 0 && (mask >> (i - 1) & 1) == 0 && nums[i] == nums[i - 1]) {
                        flag = false;
                        break;
                    }
                    list.add(nums[i]);
                }
            }
            if(flag) {
                res.add(new ArrayList<>(list));
            }
        }
        return res;
    }

    List<List<Integer>> subsetsWithDupRes = new ArrayList<>();
    public List<List<Integer>> subsetsWithDup_off2(int[] nums) {
        List<Integer> list = new ArrayList<>();
        Arrays.sort(nums);
        subsetsWithDupBackTrack(0, nums, list, false);
        return subsetsWithDupRes;
    }
    private void subsetsWithDupBackTrack(int cur, int[] nums, List<Integer> list, boolean flag) {
        if(cur == nums.length) {
            subsetsWithDupRes.add(new ArrayList<>(list));
            return;
        }
        subsetsWithDupBackTrack(cur+1, nums, list, false);
        if (!flag && cur > 0 && nums[cur - 1] == nums[cur]) {
            return;
        }
        list.add(nums[cur]);
        subsetsWithDupBackTrack(cur+1,  nums, list, true);
        list.remove(list.size() - 1);
    }

    /**
     * 78. 子集
     * @param nums
     * @return
     */
    public List<List<Integer>> subsets(int[] nums) {
        List<List<Integer>> res = new ArrayList<>();
        List<Integer> t = new ArrayList<>();
        int len = nums.length;
        for(int mask = 0; mask < (1 << len); mask++) {
            t.clear();
            for(int i = 0; i < len; i++) {
                if((mask & 1<<i) != 0) {
                    t.add(nums[i]);
                }
            }
            res.add(new ArrayList<>(t));
        }
        return res;
    }

    List<List<Integer>> subsetsRes = new ArrayList<>();
    public List<List<Integer>> subsets_off2(int[] nums) {
        List<Integer> list = new ArrayList<>();
        subsetsBackTrack(0, nums, list);
        return subsetsRes;
    }

    private void subsetsBackTrack(int cur, int[] nums, List<Integer> list) {
        if(cur == nums.length) {
            subsetsRes.add(new ArrayList<>(list));
            return;
        }
        list.add(nums[cur]);
        subsetsBackTrack(cur+1, nums, list);
        list.remove(list.size() - 1);
        subsetsBackTrack(cur+1,  nums, list);
    }

    /**
     * 781. 森林中的兔子
     * @param answers
     * @return
     */
    public int numRabbits(int[] answers) {
        int res = 0;
        Map<Integer, Integer> map = new HashMap<>();
        for(Integer item : answers) {
            map.put(item, map.getOrDefault(item, 0) + 1);
        }
        for(Map.Entry<Integer, Integer> entry : map.entrySet()) {
            int key = entry.getKey();
            int value = entry.getValue();
            res += (key + value)/(key + 1) * (key + 1);
        }
        return res;
    }


    public int numRabbits_1(int[] answers) {
        Arrays.sort(answers);
        int n = answers.length;
        int ans = 0;
        for (int i = 0; i < n; i++) {
            int cnt = answers[i];
            ans += cnt + 1;
            // 跳过「数值 cnt」后面的 cnt 个「数值 cnt」
            int k = cnt;
            while (k-- > 0 && i + 1 < n && answers[i] == answers[i + 1]) i++;
        }
        return ans;
    }

    /**
     * 153. 寻找旋转排序数组中的最小值
     * @param nums
     * @return
     */
    public int findMin(int[] nums) {
        if(nums.length == 1) {
            return nums[0];
        }
        int len = nums.length;
        int left = 0, right = len - 1, mid = 0;
        while(left < right) {
            mid = (right - left + 1)/2 + left;
            if(nums[left] < nums[mid]) {
                if(nums[left] < nums[right]) {
                    return nums[left];
                } else {
                    left = mid + 1;
                }
            } else {
                if(nums[mid] < nums[right]){
                    right = mid;
                } else {
                    return nums[right];
                }
            }
        }
        return nums[left];

    }
    public int findMin_offical(int[] nums) {
        if(nums.length == 1) {
            return nums[0];
        }
        int len = nums.length;
        int left = 0, right = len - 1, mid = 0;
        while(left < right) {
            mid = (right - left)/2 + left;
            if(nums[mid] > nums[right]) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }
        return nums[left];

    }

    /**
     * 33. 搜索旋转排序数组
     * @param nums
     * @param target
     * @return
     */
    public int search(int[] nums, int target) {
        if(nums.length == 1 && nums[0] == target) {
            return 0;
        }
        int left = 0, right = nums.length - 1, mid = 0;
        while (left < right) {
            mid = (right - left)/2 + left;
            if(target == nums[mid]) {
                return mid;
            }
            if(nums[mid] > nums[left]) {
                if(target == nums[left]) {
                    return left;
                } else if(target < nums[mid] && target > nums[left]) {
                    right = mid;
                }else {
                    left = mid + 1;
                }
            } else {
                if(target == nums[right]) {
                    return right;
                } else if(target > nums[mid] && target < nums[right]) {
                    left = mid + 1;
                } else {
                    right = mid;
                }
            }
        }
        if(left == right && nums[left] == target) {
            return left;
        }
        return -1;
    }

    /**
     * 81. 搜索旋转排序数组 II
     * @param nums
     * @param target
     * @return
     */
    public boolean search2(int[] nums, int target) {
        int len = nums.length;
        if(len == 0) {
            return false;
        }
        if(len == 1) {
            if(nums[0] == target) {
                return true;
            } else {
                return false;
            }
        }
        int left = 0, right = len - 1, mid = 0;
        while (left < right) {
            mid = (right - left)/2 + left;
            if(nums[mid] == target) {
                return true;
            }
            if(nums[mid] == nums[left] && nums[mid] == nums[right]) {
                left++;
                right--;
            } else if(nums[mid] >= nums[left]) {
                if(target == nums[left]) {
                    return true;
                } else if(target < nums[mid] && target > nums[left]) {
                    right = mid;
                }else {
                    left = mid + 1;
                }
            } else {
                if(target == nums[right]) {
                    return true;
                } else if(target > nums[mid] && target < nums[right]) {
                    left = mid + 1;
                } else {
                    right = mid;
                }
            }
        }
        if(left == right && nums[left] == target) {
            return true;
        }
        return false;
    }

    /**
     * 154. 寻找旋转排序数组中的最小值 II
     * @param nums
     * @return
     */
    public int findMin2(int[] nums) {
        int len = nums.length;
        if(len == 1) {
            return nums[0];
        }
        int left = 0, right = len - 1, mid = 0;
        while (left < right) {
            mid = (right - left) / 2 + left;
            if(nums[mid] == nums[left] && nums[mid] == nums[right]) {
                left++;
                right--;
            } else if(nums[mid] >= nums[left]) {
                if(nums[right] > nums[left]) {
                    right = mid;
                } else {

                }
            }
        }
        return nums[left];
    }

    /**
     * 179. 最大数
     * @param nums
     * @return
     */
    public String largestNumber(int[] nums) {
        Integer[] numsArr = new Integer[nums.length];
        for(int i = 0; i < nums.length; i++) {
            numsArr[i] = nums[i];
        }
        Arrays.sort(numsArr, new Comparator<Integer>() {
            @Override
            public int compare(Integer x, Integer y) {
                long sx = 10, sy = 10;
                while (sx <= x) {
                    sx *= 10;
                }
                while (sy <= y) {
                    sy *= 10;
                }
                return (int) (sx*y + x - sy*x - y);
            }
        });
        if(numsArr[0] == 0) {
            return "0";
        }
        StringBuilder sb = new StringBuilder();
        for(int num : numsArr) {
            sb.append(num);
        }
        return sb.toString();
    }

    private boolean compareString(String s1, String s2) {
        for(int i = s1.length() - 1; i >= 0; i--) {
            char item1 = s1.charAt(i);
            char item2 = s2.charAt(i);
            if(item1 > item2) {
                return true;
            } else if (item1 < item2) {
                return false;
            }
        }
        return true;
    }

    /**
     * 34. 在排序数组中查找元素的第一个和最后一个位置
     * @param nums
     * @param target
     * @return
     */
    public int[] searchRange(int[] nums, int target) {
        int left = 0, right = nums.length - 1, mid = 0;
        while (left < right) {
            mid = (right - left)/2 + left;
            if(nums[mid] == target) {
                break;
            }
            if(target < nums[mid]) {
                right = mid;
            } else {
                left = mid + 1;
            }
        }

        if(left == right && target == nums[left]) {
            return new int[]{left, right};
        }

        if(nums[mid] == target) {
            left = mid;
            right = mid;
            while (left >=0 && nums[left] == target) {
                --left;
            }
            while (right <nums.length && nums[right] == target) {
                ++right;
            }
            return new int[]{left+1, right-1};
        }
        return new int[]{-1, -1};
    }

    /**
     * 220. 存在重复元素 III
     * @param nums
     * @param k
     * @param t
     * @return
     */
    public boolean containsNearbyAlmostDuplicate(int[] nums, int k, int t) {
        int len = nums.length;
        int i = 0, j = k;
        while (i < len) {
            for(int m = i; m < j && m < len; m++) {
                if(m == 0) {
                    for( ; m < j && m < len; m++) {
                        for(int n = m + 1; n <= j && n < len; n++) {
                            if(Math.abs(Long.valueOf(nums[m]) - Long.valueOf(nums[n])) <= t) {
                                return true;
                            }
                        }
                    }
                } else {
                    for(int n = m; n < j && n < len; n++ ) {
                        int last = m+k < len ? nums[m+k] : nums[len - 1];
                        if(n < len && Math.abs(Long.valueOf(last) - Long.valueOf(nums[n])) <= t) {
                            return true;
                        }
                    }
                }
            }
            i++;
            j++;
        }
        return false;
    }

    /**
     * 26. 删除有序数组中的重复项
     * @param nums
     * @return
     */
    public int removeDuplicates(int[] nums) {
        int len = nums.length;
        if(len == 0) {
            return 0;
        }
        int fast = 1, slow = 1;
        while (fast < len) {
            if(nums[fast] != nums[fast - 1]) {
                nums[slow] = nums[fast];
                slow++;
            }
            fast++;
        }
        return slow;
    }

    /**
     * 27. 移除元素
     * @param nums
     * @param val
     * @return
     */
    public int removeElement(int[] nums, int val) {
        int len = nums.length, left = 0;
        for(int right = 0; right < len; right++) {
            if(nums[right] != val) {
                nums[left] = nums[right];
                left++;
            }
        }
        return left;
    }

    /**
     * 363. 矩形区域不超过 K 的最大数值和
     * @param matrix
     * @param k
     * @return
     */
    public int maxSumSubmatrix(int[][] matrix, int k) {
        return 0;
    }

    /**
     * 1011. 在 D 天内送达包裹的能力
     * @param weights
     * @param D
     * @return
     */
    public int shipWithinDays(int[] weights, int D) {
        int[] sum = new int[weights.length];
        sum[0] = weights[0];
        for(int i = 1; i < weights.length; i++) {
            sum[i] = weights[i] + sum[i-1];
        }
        int average = sum[weights.length-1]%D == 0 ? sum[weights.length-1]/D : sum[weights.length-1]/D +1;
        int temp = sum[0];
        int max = sum[0];
        for(int j = 1; j < sum.length; j++) {
            if(sum[j] - temp > average) {
                max = max > sum[j-1] - temp ? max : sum[j-1] - temp;
                temp = sum[j-1];
            }
        }
        return max;
    }

    /**
     * 633. 平方数之和
     * @param c
     * @return
     */
    public boolean judgeSquareSum(int c) {
        for(double a = 0; a*a < c; a++) {
            double b = Math.sqrt(c- a*a);
            if(b == (int)b) {
                return true;
            }
        }
        return false;
    }

    /**
     * 137. 只出现一次的数字 II
     * @param nums
     * @return
     */
    public int singleNumber(int[] nums) {
        int len = nums.length;
        if(nums.length == 1) {
            return nums[0];
        }
        Arrays.sort(nums);
        int left = 0;
        int right = 1;
        while (left < len) {
            right = left + 1;
            if(right < len && nums[left] == nums[right]) {
                left += 3;
            } else {
                break;
            }
        }
        return nums[left];
    }

    /**
     * 1486. 数组异或操作
     * @param n
     * @param start
     * @return
     */
    public int xorOperation(int n, int start) {
        int res = 0;
        for(int i = 0; i < n; i++) {
            res ^= start + 2*i;
        }
        return res;
    }

    /**
     * 1720. 解码异或后的数组
     * @param encoded
     * @param first
     * @return
     */
    public int[] decode(int[] encoded, int first) {
        int len = encoded.length + 1;
        int[] res = new int[len];
        res[0] = first;
        for(int i = 1; i < len; i++) {
            res[i] = res[i-1]^encoded[i-1];
        }
        return res;
    }

    /**
     * 740. 删除并获得点数
     * 注意到若 nums 中不存在某个元素 xx，则选择任一小于 xx 的元素不会影响到大于 xx 的元素的选择。因此我们可以将 nums 排序后，将其划分成若干连续子数组，子数组内任意相邻元素之差不超过 11。对每个子数组按照方法一的动态规划过程计算出结果，累加所有结果即为答案。
     * @param nums
     * @return
     */
    public int deleteAndEarn_off2(int[] nums) {
        Arrays.sort(nums);
        int res = 0;
        List<Integer> sum = new ArrayList<>();
        int size = 1;
        sum.add(nums[0]);
        for(int i = 1; i < nums.length; i++) {
            int val = nums[i];
            if(val == nums[i-1]) {
                sum.set(size-1, sum.get(size-1) + val);
            } else if(val == nums[i-1] + 1) {
                sum.add(val);
                size++;
            } else {
                res += rob(sum);
                sum.clear();
                sum.add(val);
                size = 1;
            }
        }
        res += rob(sum);
        return res;
    }

    public int rob(List<Integer> list) {
        int size = list.size();
        if(size == 1) {
            return list.get(0);
        }
        int first = list.get(0), second = Math.max(list.get(0), list.get(1));
        for(int i = 2; i < size; i++) {
            int temp = second;
            second = Math.max(first + list.get(i), second);
            first = temp;
        }
        return second;
    }

    /**
     * 740. 删除并获得点数
     * 转成sum数组，用打家劫舍的方法去做
     * @param nums
     * @return
     */
    public int deleteAndEarn(int[] nums) {
        int max = 0;
        for(Integer num : nums) {
            max = Math.max(num, max);
        }
        int[] sum = new int[max+1];
        for(Integer num : nums) {
            sum[num] += num;
        }
        /*
          dp[0] = sum[0]
          dp[1] = max {dp[0], dp[1]}
          dp[n] = max {dp[n-1], dp[n-2] + sum[i]}
         */
        return rob(sum);
    }

    /**
     * 198. 打家劫舍
     * dp[0] = nums[0]
     * dp[1] = nums[1]
     * dp[n] = max {dp[n-1], dp[n-2] + nums[i]}
     * @param nums
     * @return
     */
    public int rob(int[] nums) {
        int len = nums.length;
        int[] dp = new int[len];
        dp[0] = nums[0];
        for(int i = 1; i < len; i++) {
            dp[i] = Math.max(dp[i-1], i - 2 > 0 ? dp[i-2] + nums[i] : nums[i]);
        }
        return dp[len-1];
    }


    /**
     * 1723. 完成所有工作的最短时间
     * @param jobs
     * @param k
     * @return
     */
    public int minimumTimeRequired(int[] jobs, int k) {
        return 0;
    }

    /**
     * 1310. 子数组异或查询
     * @param arr
     * @param queries
     * @return
     */
    public int[] xorQueries(int[] arr, int[][] queries) {
        int[] res = new int[queries.length];
        int[] arrSum = new int[arr.length];
        arrSum[0] = arr[1];

        for(int i = 1; i < arr.length; i++) {
            arrSum[i] = arrSum[i-1]^arr[i];
        }

        for(int i = 0; i < queries.length; i++) {
            res[i] = arrSum[queries[i][0]] ^ arrSum[queries[i][1]];
        }
        return res;
    }



    public static void main(String[] args) {
        Test test = new Test();
//        test.countBits(5);
//        test.numDistinct("rabbbit", "rabbit");
//        test.find132pattern_official_1(new int[]{-1,1,2,1});
//        test.sortArr(new Integer[]{-1,1,2,1, -3, -2});
//        System.out.println(test.stoneGameIII(new int[]{-1,-2,-3}));
//        System.out.println(test.searchMatrix(new int[][]{{1,3}}, 3));
//        System.out.println(test.subsetsWithDup_off2(new int[]{1,2,2}));
//        System.out.println(test.findMin_offical(new int[]{3,4,5,1,2}));
//        System.out.println(test.search(new int[]{4,5,6,7,8,1,2,3}, 8));
//        System.out.println(test.search(new int[]{4,5,6,7,0,1,2}, 0));
//        System.out.println(test.search(new int[]{1,3}, 3));
//        System.out.println(test.search2(new int[]{2,2,2,0,0,1}, 0));
//        System.out.println(test.searchRange(new int[]{2,2}, 2));
//        System.out.println(test.containsNearbyAlmostDuplicate(new int[]{1,5,9,1,5,9}, 2, 3));
//        System.out.println(test.containsNearbyAlmostDuplicate(new int[]{1,2,3,4,5,2,4,5}, 3, 0));
//        System.out.println(test.containsNearbyAlmostDuplicate(new int[]{1,2,2,3,4,5}, 3, 0));
//        System.out.println(test.containsNearbyAlmostDuplicate(new int[]{2147483646,2147483647}, 3, 3));
//        System.out.println(test.removeElement(new int[]{3,2,2,3}, 3));
//          int a = -2147483648;
//          int b = 2147483647;
//        System.out.println(Long.valueOf(b) - Long.valueOf(a));
        // [2147483646,2147483647]
//        int a = 2147483646;
//          int b = 2147483647;
//        System.out.println(Long.valueOf(a) - Long.valueOf(b));

//        int j = 2;
//        for(int i = 0; i < 1; i++) {
//            System.out.println(i+j);
////            i = j;
//        }
//
//        for(int i = 0; i < 1; ++i) {
//            System.out.println(i+j);
////            int j = 2;
////            i = j;
//        }
        System.out.println(test.shipWithinDays(new int[]{1,2,3,4,5,6,7,8,9,10}, 5));
    }
}
