package com.aidar.ali;

import java.util.*;

public class Test {
    // 有A1, A2, A3... An N个集合，第i个集合Ai有Mi个元素（会有重复）
// 现在要依次从 A1, A2, A3... An 取出一个元素组成一个长度为N的字符串
// 请写一个函数打印所有可能的字符串，要求不重复
// 输入：List<List<Integer>>


    public List<List<Integer>> genPermutation(List<List<Integer>> sets){
        List<List<Integer>> res = new ArrayList<>();
        for(int i = 0; i < sets.size(); i++) {
            List<Integer> newList = new ArrayList<>();
            res.add(newList);
        }
        for(int j = 0; j < sets.size(); j++) {
            genRes(res, sets.get(j));
        }
        return res;
    }

    public void genRes(List<List<Integer>> res, List<Integer> list2) {
        Set<Integer> set1 = new HashSet<>();
        for(int i = 0; i < list2.size(); i++) {
            for(int j = 0; j < res.size(); j++) {
                if(!set1.contains(list2.get(i))) {
                    List<Integer> item = res.get(i);
                    item.add(list2.get(j));
                }
            }
        }
    }



// 有一个长度为N的数组中包含正数，负数和0，请实现一个函数找出最长和为零的连续子数组。

// 输入：所有数组元素在一行，空格隔开
// 输出：所有数组元素在一行，空格隔开

// 输入样例：1 2 3 4 -1 -2 -4 -3 1 2
    public int[] maxSubZero0(int[] nums) {
        int[] sum = new int[nums.length];
        sum[0] = nums[0];
        for (int i = 1;  i < nums.length; i++) {
            sum[i] = sum[i - 1] + nums[i];
        }
        Map<Integer, Integer> map = new HashMap<>();
        int[] ans = new int[] {-1, -1};
        for (int i = 0; i < nums.length; i++) {
            if (sum[i] == 0 && (ans[1] - ans[0]) < i) {
                ans[0] = 0;
                ans[1] = i;
            } else if (sum[i] != 0 && map.containsKey(sum[i])) {
                int start = map.get(sum[i]);
                if ((ans[1] - ans[0]) < (i - start - 1)) {
                    ans[0] = start + 1;
                    ans[1] = i;
                }
            }
            if (!map.containsKey(sum[i])) {
                map.put(sum[i], i);
            }
        }
        return ans;
    }

    public int [] maxSubZero(int[] a) {
        int b = 0;
        int startIndex = 0;
        int endIndex = 0;
        Map<Integer, List<Integer>> map = new HashMap<>();
        for(int i = 0; i < a.length; i++) {
            b += a[i];
            List list = new ArrayList();
            if(map.containsKey(b)) {
                list = map.get(b);
                list.add(i);
            } else {
                list.add(i);
                map.put(b, list);
            }
        }
        int max = -1;
        for(Map.Entry<Integer, List<Integer>> entry: map.entrySet()) {
            Integer key = entry.getKey();
            List<Integer> list = entry.getValue();
            if(key == 0) {
                int last = list.get(list.size() - 1);
                if(last > max) {
                    max = last;
                    startIndex = 0;
                    endIndex = last;
                }
            }else if(key != 0 && list.size() > 1) {
                int start = list.get(0);
                int end = list.get(list.size() - 1);
                if(end - start > max) {
                    max = end - start;
                    startIndex = start+1;
                    endIndex = end;
                }
            }
        }
        int[] res = new int[endIndex - startIndex + 1];
        for(int j = 0; j < res.length; j++) {
            res[j] = a[startIndex+j];
        }
        return res;
    }

    /**
     * 题目二
     * 给定一个字符串，请你找出其中不含有重复字符的 最长子串 的长度。
     *
     * 示例 1:
     * 输入: "abcabcbb"
     * 输出: 3
     * 解释: 因为无重复字符的最长子串是 "abc"，所以其长度为 3。
     *
     * 示例 2:
     * 输入: "bbbbb"
     * 输出: 1
     * 解释: 因为无重复字符的最长子串是 "b"，所以其长度为 1。
     *
     * 示例 3:
     * 输入: "pwwkew"
     * 输出: 3
     * 解释: 因为无重复字符的最长子串是 "wke"，所以其长度为 3。
     *      请注意，你的答案必须是 子串 的长度，"pwke" 是一个子序列，不是子串
     * @param s
     * @return
     */
    public int getMaxUnrepeatedSubLen(String s) {
        int len = s.length();
        int max = 1;
        for(int i = 0; i < len; i++) {
            Set<Character> set = new HashSet<>();
            set.add(s.charAt(i));
            for(int j = i+1; j < len; j++) {
                if(!set.contains(s.charAt(j))) {
                    set.add(s.charAt(j));
                } else {
                    max = max > set.size() ? max : set.size();
                }
            }
        }
        return max;
    }
//    题目三
//            用一条SQL语句查询出每门课都大于80分的学生姓名
//    name   course score
//    张三     语文       81
//    张三     数学       75
//    李四     语文       76
//    李四     数学       90
//    王五     语文       81
//    王五     数学       100
//    王五     英语       90
//    select t.name from (select b.name, min(score) as score from table b group by b.name) as t where t.score > 80;
//    select distinct a.name from table a where not exists (select 'x' from table b where a.name = b.name and b.score <= 80)


    /**
     *     回答：
     *     会有死锁问题，假设Stack对象Stack1，线程1持有stack1的push方法，线程1持有stack1的锁，同时持有list的锁，此时添加成功后，
     *     stack1对象notify线程2，但是线程2取到stack1对象后，获取不到list的锁，造成死锁。
     */
    public class Stack {
        LinkedList list = new LinkedList();
        public synchronized void push(Object x) {
            synchronized(list) {
                list.addLast(x);
                notify();
            }
        }

        public synchronized Object pop()
                throws Exception {
            synchronized(list) {
                if(list.size() <= 0) {
                    wait();
                }
                return list.removeLast();
            }
        }
    }



    public static void main(String[] args) {
        Test test = new Test();
        System.out.println(test.maxSubZero0(new int[]{1, 2, 3, 4, -1, -2, -4, -3, 1, 2}));
        for (int n: test.maxSubZero0(new int[]{1, 2, 3, 4, -1, -2, -4, -3, 1, 2})) {
            System.out.println(n);
        }
    }


}
